---
name: methodology-extractor
description: "Extract experimental methods from one or more papers into a structured protocol-oriented summary; use when comparing methods across studies or drafting reproducible procedures."
license: MIT
skill-author: AIPOCH
---
# Methodology Extractor

Extract and compare experimental protocols across papers.

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
```

## When to Use

- Use this skill when the task needs Batch extraction of experimental methods from multiple papers for protocol.
- Use this skill for evidence insight tasks that require explicit assumptions, bounded scope, and a reproducible output format.
- Use this skill when you need a documented fallback path for missing inputs, execution errors, or partial evidence.

## Workflow

1. Confirm the user objective, required inputs, and non-negotiable constraints before doing detailed work.
2. Validate that the request matches the documented scope and stop early if the task would require unsupported assumptions.
3. Use the packaged script path or the documented reasoning path with only the inputs that are actually available.
4. Return a structured result that separates assumptions, deliverables, risks, and unresolved items.
5. If execution fails or inputs are incomplete, switch to the fallback path and state exactly what blocked full completion.

## Use Cases
- Protocol optimization
- Methods comparison for systematic reviews
- Reproducibility assessment

## Parameters
- `paper_ids`: List of papers to analyze
- `method_type`: Target method (e.g., "Western Blot", "qPCR")

## Returns
- Comparison table of protocols
- Parameter variations across studies
- Best practice recommendations

## Example
Input: 50 papers, method_type="Western Blot"
Output: Table showing antibody concentrations, blocking conditions, wash times

## Risk Assessment

| Risk Indicator | Assessment | Level |
|----------------|------------|-------|
| Code Execution | Python/R scripts executed locally | Medium |
| Network Access | No external API calls | Low |
| File System Access | Read input files, write output files | Medium |
| Instruction Tampering | Standard prompt guidelines | Low |
| Data Exposure | Output files saved to workspace | Low |

## Security Checklist

- [ ] No hardcoded credentials or API keys
- [ ] No unauthorized file system access (../)
- [ ] Output does not expose sensitive information
- [ ] Prompt injection protections in place
- [ ] Input file paths validated (no ../ traversal)
- [ ] Output directory restricted to workspace
- [ ] Script execution in sandboxed environment
- [ ] Error messages sanitized (no stack traces exposed)
- [ ] Dependencies audited

## Prerequisites

No additional Python packages required.

## Evaluation Criteria

### Success Metrics
- [ ] Successfully executes main functionality
- [ ] Output meets quality standards
- [ ] Handles edge cases gracefully
- [ ] Performance is acceptable

### Test Cases
1. **Basic Functionality**: Standard input → Expected output
2. **Edge Case**: Invalid input → Graceful error handling
3. **Performance**: Large dataset → Acceptable processing time

## Lifecycle Status

- **Current Stage**: Draft
- **Next Review Date**: 2026-03-06
- **Known Issues**: None
- **Planned Improvements**: 
  - Performance optimization
  - Additional feature support

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `methodology-extractor` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `methodology-extractor` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.


## References

- [references/audit-reference.md](references/audit-reference.md) - Supported scope, audit commands, and fallback boundaries

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.

## When Not to Use

- 缺少完成任务所必需的输入文件、标识符、参数或上下文时，不要继续，先要求用户补充。
- 用户要求超出本 skill 已声明范围的推断、外部操作或权限时，不要自行假设具备这些能力。
- 需要覆盖已有结果、执行高成本批量操作或扩大任务范围时，不要直接继续，先和用户确认。

## Required Inputs

| 字段 | 必填 | 格式/来源 | 示例 | 缺失时处理 |
|---|---|---|---|---|
| 用户任务说明 | 是 | 文本 | 研究问题、写作目标、分析目标 | 缺失时停止并要求补充 |
| 主要输入材料 | 视任务而定 | 文本、文件路径、ID、表格或文献 | PMID、PDF、CSV、DOCX、主题词等 | 明确指出缺少哪类材料 |
| 输出偏好 | 否 | 文本 | 语言、格式、目标期刊、模板 | 未提供时采用 skill 默认格式 |

## Output Contract

- 主输出：与本 skill 目标一致的结构化结果或目标文件。
- 可选输出：中间检查说明、问题清单、补充建议或生成文件路径。
- 格式要求：除非用户另有要求，优先返回稳定、可复核的 Markdown 或 JSON；若 skill 自带脚本要求固定格式，则按该格式输出。
- 若为部分完成：必须显式标注 PARTIAL，并说明哪些步骤已完成、哪些步骤未完成。

## Failure Handling

- 缺少关键输入时：明确指出缺少的字段、文件或标识符，并暂停继续。
- 脚本、模板或资源执行失败时：报告失败步骤、可能原因和恢复建议，不要静默降级。
- 只能部分完成时：先返回已验证部分，再列出剩余阻塞项和建议的下一步。

## User Checkpoints

- 在执行批量处理、覆盖文件、长耗时检索或多阶段生成前，先向用户确认范围和输出格式。
- 在关键判断存在歧义、证据不足或需要进入下一阶段前，先向用户确认是否继续。

## Quick Validation

- 检查本 skill 依赖的关键脚本、模板或参考资料路径是否存在。
- 检查最终输出是否包含本任务约定的核心字段、章节或文件。
- 检查结果中是否清楚标注假设、限制和未完成项。
