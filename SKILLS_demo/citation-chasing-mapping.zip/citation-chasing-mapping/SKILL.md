---
name: citation-chasing-mapping
description: Maps citation networks to trace research evolution, identify influential papers, and discover hidden connections in scientific literature. Supports systematic reviews, bibliometric analysis, and research planning through comprehensive citation tracking.
license: MIT
skill-author: AIPOCH
---
# Scientific Citation Network and Knowledge Mapper

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
```

## When to Use

- Use this skill when identifying seminal papers in a research field, mapping research lineage and intellectual heritage, discovering related work through reference tracking, or finding potential collaborators through co-citation analysis.
- Use this skill for evidence insight tasks that require explicit assumptions, bounded scope, and a reproducible output format.
- Use this skill when you need a documented fallback path for missing inputs, execution errors, or partial evidence.

## When NOT to Use

- Do NOT use for simple single-paper citation lookup (use PubMed/Google Scholar directly)
- Do NOT use for systematic literature search by keywords (use literature-review skill)
- Do NOT use for bibliometric indicator calculation only (use specialized bibliometrics tools)

## Workflow

### Step 1: Define Seed Papers and Search Scope

- **Input required:** One or more seed papers (PMID, DOI, or title)
- **Optional parameters:** backward_depth (default: 2), forward_depth (default: 2), max_papers (default: 500)
- Confirm with user: which direction(s) to chase (forward citations, backward references, or both)

> **🔍 Checkpoint 1:** Present the seed paper(s) and proposed search parameters to the user. Confirm depth and scope before building the network.

### Step 2: Build Citation Network

```python
from scripts.citation_mapper import CitationNetworkMapper

mapper = CitationNetworkMapper(data_source="PubMed")
network = mapper.build_network(
    seed_paper={"pmid": "12345678", "title": "..."},
    backward_depth=2,
    forward_depth=2,
    max_papers=500
)
```

**If network building fails (API error, no citations found):**
- Retry with reduced depth parameters
- Fall back to manual citation tracking via Google Scholar "Cited by" feature
- Report which seed papers had no citation data

### Step 3: Analyze Network Structure and Detect Research Communities

- Identify seminal works using centrality metrics (betweenness, eigenvector, PageRank)
- Detect research communities using the selected algorithm (Louvain/Leiden/Label Propagation/Walktrap)
- Characterize each cluster using the structured metrics (size, density, conductance, growth rate, bridging score)
- Extract dominant topics and seminal papers per cluster
- Identify cross-cluster connections and bridging papers
- Assess network modularity (good: >0.7, acceptable: 0.4–0.7, weak: <0.4)

**Output:** Ranked list of seminal papers with centrality scores; structured cluster report with size, density, growth, bridging metrics, and cross-cluster connections.

> **🔍 Checkpoint 2:** Present the seminal papers and cluster analysis to the user. Confirm whether to proceed with visualization or refine the network parameters.

### Step 4: Generate Visualizations

```python
mapper.visualize_network(
    network=network,
    layout="force_directed",
    color_by="publication_year",
    size_by="citation_count",
    output_file="citation_network.pdf"
)
```

- Supported formats: PDF, PNG, interactive HTML
- Supported layouts: force_directed, circular, hierarchical

### Step 5: Deliver Results

- Export network data: GEXF (for Gephi), JSON, or CSV
- Generate summary: top seminal papers, cluster descriptions, research lineage map
- Note limitations: coverage depends on data source completeness

## When to Use This Skill

- identifying seminal papers in a research field
- mapping research lineage and intellectual heritage
- discovering related work through reference tracking
- finding potential collaborators through co-citation analysis
- tracking citation patterns to identify research trends
- building literature reviews with comprehensive coverage

## Quick Start

```python
from scripts.main import CitationChasingMapping

# Initialize the tool
tool = CitationChasingMapping()

from scripts.citation_mapper import CitationNetworkMapper

mapper = CitationNetworkMapper(data_source="PubMed")

# Build citation network from seed paper
network = mapper.build_network(
    seed_paper={
        "pmid": "12345678",
        "title": "Breakthrough Discovery in Immunotherapy"
    },
    backward_depth=2,  # references of references
    forward_depth=2,   # citing papers of citing papers
    max_papers=500
)

# Identify seminal papers
seminal_papers = mapper.identify_seminal_works(
    network=network,
    min_citations=100,
    centrality_threshold=0.8
)

print(f"Found {len(seminal_papers)} highly influential papers:")
for paper in seminal_papers[:5]:
    print(f"  - {paper.title} (cited {paper.citation_count} times)")

# Find research clusters
clusters = mapper.identify_research_clusters(
    network=network,
    algorithm="louvain",
    min_cluster_size=10
)

# Generate collaboration map
collaboration_map = mapper.generate_collaboration_network(
    network=network,
    institution_field="affiliation"
)

# Create visualization
mapper.visualize_network(
    network=network,
    layout="force_directed",
    color_by="publication_year",
    size_by="citation_count",
    output_file="citation_network.pdf"
)
```

## Core Capabilities

### 1. Build Comprehensive Citation Networks

Construct bidirectional citation graphs from seed papers with configurable depth.

```python
# Build network from multiple seed papers
network = mapper.build_network(
    seed_papers=[
        {"pmid": "12345678", "title": "Original Discovery"},
        {"pmid": "87654321", "title": "Follow-up Study"}
    ],
    backward_depth=3,  # References
    forward_depth=2,   # Citing papers
    max_papers=1000,
    include_citations=True
)

# Export network for Gephi
mapper.export_network(network, format="gexf", file="network.gexf")
```

### 2. Identify Seminal Works

Use centrality metrics to find field-defining papers.

```python
# Calculate centrality metrics
centrality = mapper.calculate_centrality(
    network=network,
    metrics=["betweenness", "eigenvector", "pagerank"]
)

# Identify seminal papers
seminal = mapper.identify_seminal_works(
    centrality=centrality,
    min_citations=100,
    top_n=20
)

for paper in seminal:
    print(f"{paper.title}: {paper.centrality_score}")
```

### 3. Research Community Detection and Cluster Analysis (v1.1.0 Enhanced)

Detect research communities, subfields, and emerging topic areas within the citation network. This is a core analytical capability that reveals the intellectual structure of a research field.

#### 3a. Community Detection Methodology

The skill applies multiple community detection algorithms to partition the citation network into research communities:

| Algorithm | Best For | Description |
|---|---|---|
| **Louvain** (default) | Large networks | Modularity optimization via hierarchical agglomeration; fast and scalable |
| **Leiden** | Higher quality clusters | Refinement of Louvain; guarantees well-connected communities |
| **Label Propagation** | Very large networks | Near-linear time; useful for initial exploration |
| **Walktrap** | Hierarchical structure | Random-walk-based; reveals nested community structure |

**Resolution parameter:** Adjustable (default 1.0). Higher values produce more, smaller clusters (finer subfields). Lower values produce fewer, larger clusters (broader research areas).

#### 3b. Cluster Characterization Metrics

For each detected community, calculate and report:

| Metric | Description | Interpretation |
|---|---|---|
| **Size** | Number of papers in cluster | Larger clusters indicate more active research areas |
| **Internal density** | Ratio of within-cluster to between-cluster edges | High density → cohesive, well-integrated research community |
| **Conductance** | Fraction of total edge volume leaving the cluster | Low conductance → well-separated community |
| **Average publication year** | Mean year of cluster papers | Older → established field; newer → emerging area |
| **Growth rate** | Papers/year trend over last 5 years | Positive → growing; negative → declining |
| **Top keywords** | Most frequent terms in titles/abstracts | Reflects dominant research themes |
| **Seminal paper** | Most cited paper within cluster | Foundational work for that subfield |
| **Bridging score** | Number of citations to/from other clusters | High → interdisciplinary bridging paper |

#### 3c. Structured Cluster Report Output

When presenting cluster analysis, use this structured format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESEARCH COMMUNITY DETECTION REPORT (v1.1.0)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Algorithm Used: Louvain (resolution=1.0)
Number of communities detected: 5
Modularity score: 0.72 (good community structure)

─── Cluster 1: "Machine Learning in Medical Imaging" (size: 43 papers) ───
  Internal density:    0.31  (cohesive community)
  Conductance:         0.18  (well-separated)
  Avg pub year:        2021  (active, growing field)
  Growth rate:         +12 papers/year  (rapidly growing)
  Top keywords:        deep learning, CNN, segmentation, MRI, radiomics
  Seminal paper:       Smith et al. 2018 (cited 45 times within cluster)
  Bridging score:      0.42  (moderate cross-field influence)
  Description:         Deep learning methods for automated medical image 
                       analysis, focusing on convolutional neural networks 
                       for tumor segmentation and classification.

─── Cluster 2: "Immunotherapy Biomarkers" (size: 28 papers) ───
  Internal density:    0.25  (moderate cohesion)
  Conductance:         0.22  (adequate separation)
  Avg pub year:        2022  (emerging field)
  Growth rate:         +8 papers/year
  ...

─── Cross-Cluster Connections ───
  Cluster 1 ↔ Cluster 2:  7 bridging citations (radiomics-guided immunotherapy)
  Cluster 2 ↔ Cluster 3:  12 bridging citations
  ...

─── Key Findings ───
  1. Two main research communities dominate the network
  2. Cluster 1 is the largest and fastest-growing subfield
  3. 3 bridging papers connect the ML and immunology communities
  4. Cluster 4 has declining growth — consider whether it's saturated or stagnant
  
─── Recommendations ───
  - For literature review: focus on Clusters 1 and 2
  - For research planning: cluster 2 has the highest growth-to-competition ratio
```


### 4. Generate Interactive Visualizations

Create publication-ready network visualizations.

```python
# Create interactive visualization
viz = mapper.visualize(
    network=network,
    layout="force_directed",
    node_color="publication_year",
    node_size="citation_count",
    edge_color="citation_type",
    interactive=True
)

# Save as HTML for web
viz.save_html("citation_network.html")

# Save static for publication
viz.save_pdf("figure_1.pdf", dpi=300)
```

## Command Line Usage

```text
python scripts/main.py --seed-pmid 12345678 --depth 2 --max-papers 500 --output network.json --visualize
```

## Best Practices

- Start with high-quality seed papers
- Set reasonable depth limits to avoid noise
- Validate key papers through multiple sources
- Update networks regularly as literature evolves

## Quality Checklist

Before using this skill, ensure you have:
- [ ] Clear understanding of your objectives
- [ ] Necessary input data prepared and validated
- [ ] Output requirements defined
- [ ] Reviewed relevant documentation

After using this skill, verify:
- [ ] Results meet your quality standards
- [ ] Outputs are properly formatted
- [ ] Any errors or warnings have been addressed
- [ ] Results are documented appropriately
- [ ] (v1.1.0) Community detection report includes modularity score, per-cluster metrics, and cross-cluster bridging analysis
- [ ] (v1.1.0) Cluster descriptions provide actionable insights for literature review or research planning

## References

- `references/guide.md` - Comprehensive user guide
- `references/examples/` - Working code examples
- `references/api-docs/` - Complete API documentation

---

**Skill ID**: 193 | **Version**: 1.0 | **License**: MIT

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `citation-chasing-mapping` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `citation-chasing-mapping` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.


## References

- [references/audit-reference.md](references/audit-reference.md) - Supported scope, audit commands, and fallback boundaries

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.
