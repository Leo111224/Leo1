---
name: randomization-gen
description: Generates randomization sequences for RCTs including simple, blocked, and stratified allocation. Produces sealed randomization lists ready for allocation concealment.
license: MIT
skill-author: AIPOCH
---
# Randomization Gen

RCT randomization table generator.

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
```

## When to Use

- Use this skill when designing trial randomization, generating allocation sequences, or creating block randomization tables.
- Use this skill when the user says "randomization", "random allocation", "block randomization", "stratified randomization", or "RCT design".
- Use this skill when you need sealed randomization lists ready for allocation concealment.

## Workflow

1. **Collect parameters**: Gather n_subjects (total sample size), n_groups (number of arms), block_size (must be multiple of n_groups), and optional stratification factors.
2. **Validate inputs**: Verify n_subjects > 0, n_groups >= 2, block_size is a multiple of n_groups, and n_subjects is divisible by block_size. If invalid, report exact constraint violated and stop.
3. **Checkpoint**: Display allocation plan summary (N per group, block structure, total blocks) to user for confirmation before generating sequence.
4. **Generate sequence**: Create randomization list using blocked randomization. Shuffle block contents using a reproducible seed if provided.
5. **Allocation concealment verification (v1.1.0)**: Run the generated sequence through the concealment verification checklist. Report pass/fail for each concealment criterion.
6. **Output**: Return sealed randomization list with block assignments, allocation concealment metadata, and verification report.
7. **Fallback**: If block_size is not a multiple of n_groups, suggest the nearest valid block sizes and proceed only after user confirmation.

## Allocation Concealment Verification (v1.1.0)

### Why This Matters

Allocation concealment prevents selection bias by ensuring that the person enrolling participants cannot predict the next group assignment. Unlike blinding (which conceals after allocation), concealment operates **before and during** enrollment. Inadequate concealment is associated with inflated treatment effect estimates (odds ratio for inadequate vs adequate: ~1.4).

### Verification Checklist

After generating the randomization sequence, systematically evaluate each concealment criterion:

| # | Concealment Criterion | Verification Question | Status (Pass/Warn/Fail) | Evidence |
|---|---|---|---|---|
| 1 | **Sequence unpredictability** | Is the next allocation in each block unpredictable? | | |
| 2 | **Block size non-disclosure** | Are block sizes not disclosed to enrolling staff? | | Block sizes should be known only to the randomization team |
| 3 | **Variable block sizes (recommended)** | Are multiple block sizes used to prevent end-of-block prediction? | | Use 2–3 different block sizes (e.g., 4 and 6) for better concealment |
| 4 | **Centralized allocation** | Is the sequence held centrally (web/phone/pharmacy), not at the enrollment site? | | Centralized systems prevent tampering |
| 5 | **Sequentially numbered containers** | If using sealed envelopes, are they opaque, sequentially numbered, and tamper-evident? | | Envelopes are inferior to centralized systems |
| 6 | **Stratification concealment** | If stratified, are stratum assignments determined before randomization? | | Stratum must be determined by baseline data, not post-randomization judgment |
| 7 | **Seed reproducibility** | Can the sequence be reproduced given the seed and parameters? | | Enable audit trail |
| 8 | **Audit trail** | Are all sequence generations logged with timestamp and parameters? | | |

### Concealment Methods — Guidance

| Method | Security Level | Recommended For | Notes |
|---|---|---|---|
| Centralized web/phone randomization | **Highest** | Multi-center RCTs | Gold standard; prevents tampering entirely |
| Pharmacy-controlled | **High** | Drug/device trials | Pharmacist dispenses pre-packaged identical kits |
| Sequentially numbered, opaque, sealed envelopes (SNOSE) | **Moderate** | Small single-center trials | Risk of manipulation if not properly monitored |
| Open list at enrollment site | **No concealment** | Never acceptable | Predictable; introduces severe selection bias |

### Concealment Verification Output

After running the verification, produce a summary:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ALLOCATION CONCEALMENT VERIFICATION REPORT (v1.1.0)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Sequence Parameters:
  Subjects: 120 | Groups: 3 (A, B, C) | Block size: 6 | Total blocks: 20
  Variable block sizes: NO (single block size — consider using multiple for better concealment)
  Sealed seed: YES (seed=12345)

Concealment Checks:
  ✅ Sequence unpredictability per block: PASS
  ✅ Block size non-disclosure: PASS (block size not exposed in output)
  ⚠️ Variable block sizes: WARN — single block size used; consider mixing 4/6
  ✅ Centralized allocation: ASSUMED (verify site practice)
  ✅ Seed reproducibility: PASS
  ✅ Audit trail: PASS

Overall Concealment Rating: ADEQUATE
  - Strength: Unpredictable within-block sequence, reproducible seed
  - Recommendation: Use variable block sizes (4, 6) to prevent end-of-block prediction
  - Risk: If sealed envelopes are used instead of centralized allocation, risk increases to Moderate
```

## Use Cases
- Clinical trial design
- Animal study randomization
- Blocked randomization
- Stratified allocation

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `n_subjects` | int | Yes | Total sample size |
| `n_groups` | int | Yes | Number of arms/groups |
| `block_size` | int | Yes | Block size (must be multiple of n_groups) |
| `--output` | string | No | Output file path (default: randomization.txt) |

## Returns
- Randomization sequence
- Block assignments
- Allocation concealment ready

## Example
Input: n=120, 3 groups, block=6
Output: Sealed randomization list

## References

- [references/audit-reference.md](references/audit-reference.md) - Supported randomization modes, audit commands, and fallback boundaries

## Risk Assessment

| Risk Indicator | Assessment | Level |
|----------------|------------|-------|
| Code Execution | Python/R scripts executed locally | Medium |
| Network Access | No external API calls | Low |
| File System Access | Read input files, write output files | Medium |
| Instruction Tampering | Standard prompt guidelines | Low |
| Data Exposure | Output files saved to workspace | Low |

## Security Checklist

- [ ] No hardcoded credentials or API keys
- [ ] No unauthorized file system access (../)
- [ ] Output does not expose sensitive information
- [ ] Prompt injection protections in place
- [ ] Input file paths validated (no ../ traversal)
- [ ] Output directory restricted to workspace
- [ ] Script execution in sandboxed environment
- [ ] Error messages sanitized (no stack traces exposed)
- [ ] Dependencies audited

## Prerequisites

No additional Python packages required.

## Evaluation Criteria

### Success Metrics
- [ ] Successfully executes main functionality
- [ ] Output meets quality standards
- [ ] Handles edge cases gracefully
- [ ] Performance is acceptable

### Test Cases
1. **Basic Functionality**: Standard input → Expected output
2. **Edge Case**: Invalid input → Graceful error handling
3. **Performance**: Large dataset → Acceptable processing time

## Lifecycle Status

- **Current Stage**: Draft
- **Next Review Date**: 2026-03-06
- **Known Issues**: None
- **Planned Improvements**: 
  - Performance optimization
  - Additional feature support

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `randomization-gen` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `randomization-gen` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.
