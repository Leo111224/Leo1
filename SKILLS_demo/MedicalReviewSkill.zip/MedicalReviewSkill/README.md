# Medical Review Skill

这是一个专门用于撰写长篇、高质量医学综述的工作流引擎。

## features

- 分步架构：大纲构建 → PubMed检索 → 分章撰写 → 结论总结 → 摘要定稿 → 引用格式化
- 自动化PubMed检索与引用管理
- 严格的引用规范与格式检查

详细说明请参阅 `SKILL.md`。
