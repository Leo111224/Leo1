# 工作流详细说明

本文档提供MedicalReviewSkill六步工作流的详细说明和最佳实践。

## 第一阶段：大纲构建 (Outline)

### 目标
创建清晰、结构化的综述大纲，为后续工作奠定基础。

### 详细步骤

1. **分析主题**
   - 理解用户提供的研究主题
   - 识别关键研究问题
   - 确定综述的范围和边界

2. **创建 outline.md 文件**
   - 使用markdown格式
   - 确保结构层次清晰

3. **大纲内容要求**

   **Title（标题）**：
   - 清晰表达综述主题
   - 包含关键词以便检索
   - 长度适中（建议15-25字）

   **Introduction（前言）**：
   - 研究背景：为什么这个主题重要？
   - 现状分析：目前研究到了什么程度？
   - 问题提出：存在哪些知识空白或争议？

   **Body Sections（正文章节）**：
   - 规划 3-5 个主要章节（二级标题 `##`）。
   - ⚠️ **强制要求**：大纲设计**必须深入到子标题层级**（三级标题 `###`）。每个章节必须设计 2-4 个具体的子标题，通过子标题展示该章节将如何进行逻辑拆解。严禁停留在仅有章节标题的粗略层面。
   - 确保逻辑流程：从基础到应用，从问题到解决方案。

   **Conclusion（结论）**：
   - 预设结论的方向和要点
   - 考虑未来研究方向

### 最佳实践
- 与用户确认大纲后再进行下一步
- 大纲应该具有灵活性，后续可根据文献调整
- 确保章节之间有清晰的逻辑关系

---

## 第二阶段：数据检索与库构建 (Retrieval & Database)

### 目标
为每个章节收集充足的、高质量的文献证据。

### 详细步骤

1. **生成检索词**
   - 针对outline.md中的每个主要章节
   - ⚠️ **特别提醒**：必须专门为 **Introduction** 设计检索词（如疾病流行病学、致病机制综述等）
   - 使用MeSH术语和自由词结合
   - 考虑同义词和相关概念

2. **执行检索与自动入库**

   **命令格式**：
   ```bash
   python scripts/pubmed_search.py "YOUR QUERY" --section "SectionName"
   ```

   **参数说明**：
   - `YOUR QUERY`：PubMed检索式
   - `--section`：章节名称（**严格对应文件名为准**）
     - 必须使用：`introduction`, `section_1`, `section_2`, `section_3`...
     - ❌ **禁止使用**：`Section1_History`, `Intro`, `part1` 等自定义名称
     - 原因：后续的 `read_references.py` 需要根据文件名自动匹配引用
   - `--max`：最大结果数（可选，默认20）
   - `--file`：输出文件路径（可选，默认 `references.json`）

   ⚠️ **重要提醒**：
   - `references.json` 应保存在**项目目录**（如 `TP53/references.json`），而非 skill 目录
   - 如果在 skill 目录运行脚本，请使用 `--file ../ProjectName/references.json` 指定正确路径
   - 这样可以确保每个项目的文献库独立管理

   **示例**：
   ```bash
   python scripts/pubmed_search.py "diabetes mellitus[MeSH] AND complications" --section "introduction" --max 20
   python scripts/pubmed_search.py "metformin mechanism" --section "section_1" --max 20
   ```

3. **循环迭代与数量检查**
   - **检查命令**：`python scripts/count_references.py`
   - **数量要求**：总去重 PMID 数量必须 **> 150 篇**
   - **操作建议**：
     - 如果数量不足，使用更广泛的关键词或同义词再次检索
     - 增加 `--max` 参数（例如设置为 20 或 50）获取更多结果
   - 脚本会自动追加新结果，不会重复添加相同PMID

4. **检索策略建议**
   - Introduction：综述性文献、流行病学数据
   - Methods/Mechanisms：机制研究、实验研究
   - Clinical sections：临床试验、Meta分析
   - Future directions：最新研究、综述

### 注意事项
- 目标是建立一个庞大的文献库（>200篇），以便在写作时有充足的选择
- 优先选择近5年的高质量文献
- 包含一些经典的奠基性文献

---

## 第三阶段：分章撰写 (Drafting)

### 目标
基于文献证据，撰写每个章节的详细内容，并确保引用多样性。

### 详细步骤

1. **读取章节专属文献**


   **命令示例**：
   ```bash
   python scripts/read_references.py "Introduction"
   ```

   该脚本会从references.json中过滤出标记为"Introduction"的所有文献，并显示：
   - PMID
   - 标题
   - 摘要
   - 年份
   - 检索式（用于追溯）

2. **撰写章节内容**

   **文件命名规范**：
   - `introduction.md` - 对应大纲中的 Introduction 部分
   - `section_1.md` - 对应大纲第一个主要章节
   - `section_2.md` - 对应大纲第二个主要章节
   - 以此类推

   **写作要求**：
   - 每个观点都需要文献支持
   - 使用 `[PMID: 123456]` 格式标注引用
   - 保持客观、严谨的学术语言
   - 适当使用表格和图示说明复杂概念
   - ⚠️ **重要**：使用完整段落,避免简单的要点式列表
     - 错误示例："1. **突变异质性**：超过 1000 种不同的 TP53 突变..."
     - 正确示例："首要挑战是 TP53 突变的高度异质性。超过 1000 种不同的 TP53 突变..."
     - 参考 `assets/Review_Final.md` 中的完整段落写法

   **格式与结构要求**（⚠️ **极易犯错的点**）：
   - 章节主标题：二级标题 `## 1. 章节名`
   - 子标题：三级标题 `### 1.1 子标题名`
   - ⚠️ **强制要求**：**严禁将整个 Section 写成单一的超长段落**。每个主章节（`##`）必须由 2-4 个具备细分逻辑的子标题（`###`）构成。
   - ⚠️ **引用密度要求**：**单句话的引用数量最多不得超过 2 篇**（即最多只允许诸如 `[PMID: 111] [PMID: 222]`）。若有多篇相似结论的文献，请将其拆分为递进的独立复句分层次展开描述，杜绝在句末毫无营养地堆砌参考文献。
   - 参考 `assets/Review_Final.md`：观察其子标题是如何将一个大主题拆解并进行结构化论述的。
   
3. **边写边检索 (Search-While-Writing)**
   - **场景**：写作过程中发现某个具体观点缺乏文献支持，或现有文献过于陈旧。
   - **行动**：不要停下来，立即进行微型检索。
   - **命令**：
     ```bash
     python scripts/pubmed_search.py "specific mechanism or recent data" --section "section_1"
     ```
   - **集成**：新检索到的文献会自动添加到 `references.json`，再次运行 `read_references.py "section_1"` 即可查看。

4. **写作后校验与文献补充 (Post-Writing Check)**
   - 单章写完后，运行校验脚本检查客观指标：
     ```bash
     python scripts/check_section.py "section_1.md"
     ```
   - 重点关注状态机输出的**参考文献数**及**下一步建议**。
   - 若引用的PMID数量过少（如<10），请执行带 `--post-write` 参数的补充检索：
     ```bash
     python scripts/pubmed_search.py "Your Query" --section "section_1" --post-write
     ```
   - 根据补充检索后的状态提示，读取新文献补入该章节。

5. **人工质量检查**
   - 每个段落是否有足够的文献支持？
   - 逻辑是否连贯？
   - 是否回答了大纲中设定的问题？

### 写作建议
- 先写主干内容，再补充细节
- 保持段落长度适中（3-5句）
- 使用过渡句连接段落

---

## 第四阶段：结论撰写 (Conclusion)

### 目标
总结全文核心发现，呼应前言，展望未来。

### 详细步骤

1. **回顾已完成章节**
   - 快速浏览所有section_*.md文件
   - 提取每个章节的关键发现
   - 识别贯穿全文的主题

2. **撰写 conclusion.md**

   **内容结构建议**：
   - **总结核心发现**：简洁概括主要结论
   - **呼应前言问题**：回答Introduction中提出的问题
   - **指出研究局限**：诚实指出当前研究的不足
   - **未来研究方向**：提出有价值的研究建议
   - ⚠️ **重要规则**：结论部分**不要包含参考文献**，这是一般综述的写作惯例

   **格式要求**：
   - 主标题：二级标题 `## 结论`
   - 子标题：三级标题 `### 总结核心发现`等
   - 参考 `assets/Review_Final.md` 的结论部分

### 写作原则
- 避免引入新的内容或文献
- 保持与前言的呼应
- 结论应该简洁有力

---

## 第五阶段：摘要与定稿 (Abstract & Final Assembly)

### 目标
撰写摘要，合并所有部分，生成完整的综述文档。

### 详细步骤

1. **撰写 abstract.md**

   **内容要求**：
   - 研究背景（1-2句）
   - 主要内容概述（3-4句）
   - 核心发现（2-3句）
   - 结论与展望（1-2句）
   - ⚠️ **不要包含引用**：摘要通常是一个独立的文本，不应依赖参考文献
   - 关键词：5-7个，用中文分号"；"分隔

   **格式要求**：
   - 第一行：完整标题（一级标题 `#`）
   - 第二个标题："摘要"（二级标题 `##`）
   - 第三个标题："关键词"（三级标题 `###`）
   - 参考 `assets/Review_Final.md` 的开头部分

   ⚠️ **常见错误**：
   - **忘记添加综述标题**：`abstract.md` 的第一行必须是完整的综述标题（一级标题）
   - **关键词分隔符错误**：必须使用中文分号（；）分隔，不是英文分号（;）

2. **合并定稿**

   **命令示例**：
   ```bash
   python scripts/merge_review.py abstract.md introduction.md section_1.md section_2.md section_3.md conclusion.md -o Review_Final.md
   ```

   **注意**：
   - 按正确顺序列出所有文件
   - ⚠️ **不要包含 `outline.md`**：大纲仅用于规划，不应出现在最终文档中
   - 输出文件统一命名为 Review_Final.md

3. **格式核对**
   - 打开 Review_Final.md 和 assets/Review_Final.md
   - 核对标题层级结构是否一致
   - 检查整体格式是否符合模板规范

---

## 第六阶段：格式化引用 (Format Citations)

### 目标
将PMID引用转换为标准格式，并生成参考文献列表。

### 详细步骤

1. **运行格式化脚本**

   **命令示例**：
   ```bash
   python scripts/format_citations.py Review_Final.md -o Review_Final_Formatted.md
   ```

   **脚本功能**：
   - 将 `[PMID: 123456]` 替换为 `[[n]](https://pubmed.ncbi.nlm.nih.gov/123456/)`
   - 自动编号引用
   - 调用PubMed API获取完整引文信息
   - 在文末生成APA格式的参考文献列表

2. **验证输出**
   - 检查所有引用链接是否正确
   - 确认参考文献列表完整
   - 验证编号顺序

3. **内容修改与引用回退 (Revising Content)**
   - **场景**：如果发现排版后的最终版（具有 `[[1]](链接)` 样式）需要大修或补充内容。
   - ⚠️ **强制要求**：**切忌直接在带链接的最终版上强行修改**，这会导致引用编号混乱。
   - **第一步 (回退)**：执行回退脚本，将排版过后的引用格式转换回原始的 `[PMID: xxx]` 形式，并自动去除文末的参考文献列表。
     ```bash
     python scripts/revert_citations.py "Review_Final_Formatted.md" -o "Review_Final_Draft.md"
     ```
   - **第二步 (修改)**：在新生成的 `Review_Final_Draft.md` 上进行所有的内容删减或补充。随时可用 `pubmed_search.py` 补充新文献，并继续遵守 `[PMID: xxx]` 的原始标注格式。
   - **第三步 (重新排版)**：全部修改完毕后，再次运行格式化脚本，生成新的最终版。
     ```bash
     python scripts/format_citations.py "Review_Final_Draft.md" -o "Review_Final_Formatted_v2.md"
     ```

### 注意事项
- 网络连接需要稳定（调用PubMed API）
- 处理时间取决于引用数量
- 如果某些PMID无法获取，会有警告提示

---

## 常见问题与解决方案

### Q1: 检索到的文献不够相关怎么办?
A: 优化检索词,使用更精确的MeSH术语,或调整检索策略。

### Q2: 如何处理重复的PMID?
A: 脚本会自动检测并跳过同一章节的重复PMID。

### Q3: 合并时文件顺序错了怎么办?
A: 重新运行merge_review.py,按正确顺序指定文件。

### Q4: 格式化引用时出现错误?
A: 检查网络连接,确认所有PMID格式正确。

### Q5: references.json 应该放在哪里?
A: **必须放在项目目录**（如 `TP53/references.json`）,而非 skill 目录。如果在 skill 目录运行脚本,使用 `--file ../ProjectName/references.json` 指定正确路径。

### Q6: abstract.md 缺少标题怎么办?
A: `abstract.md` 的第一行必须是完整的综述标题（一级标题 `#`）,然后才是 `## 摘要` 部分。参考 `assets/Review_Final.md` 的格式。
