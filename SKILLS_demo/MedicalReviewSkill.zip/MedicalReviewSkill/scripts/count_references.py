import json
import argparse
import os

def count_references(filename="references.json"):
    if not os.path.exists(filename):
        print(f"Error: {filename} not found.")
        return

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except json.JSONDecodeError:
        print(f"Error: Failed to decode {filename}.")
        return

    unique_pmids = set()
    section_counts = {}

    for entry in data:
        pmid = entry.get('pmid')
        section = entry.get('section', 'Unknown')
        
        if pmid:
            unique_pmids.add(pmid)
        
        section_counts[section] = section_counts.get(section, 0) + 1

    total_unique = len(unique_pmids)
    
    print(f"\n--- Reference Statistics ---")
    print(f"Total Unique PMIDs: {total_unique}")
    print(f"Total Entries: {len(data)}")
    print(f"\n--- By Section ---")
    for section, count in section_counts.items():
        print(f"{section}: {count}")
    
    if total_unique < 200:
        print(f"\n⚠️  Warning: Unique references ({total_unique}) are fewer than the recommended target of 200.")
    else:
        print(f"\n✅ Target reached: >200 unique references available.")

    print("\n" + "="*40)
    print("【状态机 (State Machine)】")
    print("当前状态: 阶段二 (Data Retrieval) - 检查文献数量完成。")
    print("下一步建议: ")
    print("- 若 PMIDs >= 150，进入阶段三，运行 `read_references.py` 读取文献并开始撰写各个章节。")
    print("- 若文献不足，请使用 `pubmed_search.py` 补充检索。")
    print("="*40 + "\n")

def main():
    parser = argparse.ArgumentParser(description="Count unique references in references.json")
    parser.add_argument("--file", default="references.json", help="Path to references.json file")
    args = parser.parse_args()
    
    count_references(args.file)

if __name__ == "__main__":
    main()
