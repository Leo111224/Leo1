---
name: Medical Review Writer (Architect)
description: 用于撰写长篇医学综述的多阶段工作流；当用户需要基于 PubMed 文献构建大纲、分章写作、补充检索并格式化引用时使用；输入为综述主题和项目目录，输出为带 PMID 引用的完整综述文稿及中间文件。
license: MIT
skill-author: AIPOCH
---

# Medical Review Writer (Architect)

## When to Use

- 用户明确要写医学综述、叙述性综述或基于 PubMed 证据的长篇 review。
- 用户接受按大纲、检索、分章写作、校验和格式化的多阶段流程推进。
- 用户需要真实中间文件，而不是一次性在对话中直接生成最终长文。

## When Not to Use

- 用户只需要摘要、单段综述或简短背景介绍时，不要启动整套长流程。
- 用户没有主题、目标读者、语言要求或项目目录时，不要直接开始写作，先补齐最小输入。
- 当前任务不允许创建或修改中间文件时，不要使用本技能，因为其核心流程依赖真实文件和状态机检查。

## Required Inputs

| 字段 | 必填 | 格式/来源 | 示例 | 缺失时处理 |
|---|---|---|---|---|
| `topic` | 是 | 文本 | `TP53 in lung cancer` | 缺失时停止并要求补充 |
| `project_dir` | 是 | 本地目录 | `TP53/` | 缺失时先确认工作目录 |
| `language` | 否 | 文本 | `中文` / `English` | 未提供时默认中文 |
| `target_scope` | 否 | 文本 | narrative review / mini review | 未提供时按标准长综述执行 |

## Output Contract

- 主输出：`Review_Final.md` 与 `Review_Final_Formatted.md`。
- 中间文件：`outline.md`、`references.json`、`introduction.md`、`section_*.md`、`abstract.md`、`conclusion.md`。
- 引用格式：正文只使用 `[PMID: xxx]` 作为中间标引，最终再格式化。
- 若流程中断：必须说明完成到了哪一阶段、缺少什么，且标记为 `PARTIAL`。

## User Checkpoints

- 大纲完成后必须让用户确认，再进入检索与写作阶段。
- 每章校验通过后必须汇报当前章节状态，并在进入下一章前获得用户确认。

## 核心工作流

严格按照以下六步流程执行。**核心机制**：每次执行脚本后，终端会打印【状态机 (State Machine)】提示，请严格阅读当前状态并按照“下一步建议”操作。

### 第一阶段：大纲构建 (Outline)

1. 分析主题并规划 3-5 个主要章节 (Body Sections)。
2. ⚠️ **核心强制要求**：撰写大纲时**必须精确到子标题级别**（即 `### 1.1`, `### 1.2` 等）。每个主要章节下需预先规划 2-4 个具备细分逻辑的子标题，绝不允许只写到 `## 1. 章节名`。
3. 创建 `outline.md`。必须包含：Title, Introduction, Body Sections (包含所有子标题), Conclusion。
4. 与用户确认大纲后再进行下一步。

**详细说明**：参见 [references/workflow-details.md](references/workflow-details.md) 第一阶段

### 第二阶段：数据检索与库构建

1. 针对每个章节（**必须包含 Introduction**）设计检索策略
2. 执行检索：`python scripts/pubmed_search.py "QUERY" --section "introduction|section_1|..."`
   - ⚠️ **命名规范**：`--section` 必须严格对应文件名（例如 use `introduction` NOT `Intro`, use `section_1` NOT `Section1_TP53`），以便后续脚本自动匹配
   - **批量检索**：脚本已启用批量获取 PMID 详情，提高检索效率
   - **速率限制**：自动控制约 1 请求/秒，确保稳定性和 API 合规
   - **默认数量**：`--max` 默认为 20 篇，可根据需要调整
   - **安全检查**：自动处理缺失的 PMID 或标题字段
   - ⚠️ **重要**：`references.json` 应保存在**项目目录**（如 `TP53/references.json`），而非 skill 目录
3. **检查数量**：运行 `python scripts/count_references.py`
   - **目标**：确保 `references.json` 中总 Unique PMIDs **至少达到 150 篇**
   - 如果不足，必须优化检索词补充检索
4. 确保每个章节都有充足文献支持

**详细说明**：参见 [references/workflow-details.md](references/workflow-details.md) 第二阶段

### 第三阶段：分章撰写

1. 读取章节文献：`python scripts/read_references.py "SectionName"`
2. 创建 `introduction.md` (前言) 以及 `section_1.md`, `section_2.md` 等正文文件
3. **格式与字数要求**（参考 `assets/Review_Final.md`）：
   - ⚠️ **切忌将整个 Section 写成单个长段落**！每个主章节（如 `## 1. xxx`）下**必须划分 2-4 个具体的子标题**（如 `### 1.1 xxx`）。
   - 每个子标题下的内容必须展开为详尽、连贯的学术段落，不得使用简单的要点列表缩写。
4. **文献引用标引**：每个客观学术观点都需文献支持，使用 `[PMID: xxx]` 格式标注。
5. **边写边检索 (Dynamic Retrieval)**：如果发现论据不足，立即执行补充检索：
   - `python scripts/pubmed_search.py "Specific Query" --section "CurrentSection"`
6. **写作后校验与补充**：
   - 单章写完后必须验证：`python scripts/check_section.py "section_1.md"`
   - 若状态机提示引用不足，根据建议带 `--post-write` 参数进行补充检索。
   - 若状态机提示字数不足预定规模要求（即 < 7000 字），须根据需要进一步扩充各个子标题的内容深度。
   - 若状态机提示发现密集引用（即某单句话包含 > 2 篇参考文献），须展开修改该句，将多篇引用拆分论述，**禁止一句话结尾堆砌超过2篇文献**。
   - **强制要求**：只要校验完全达标（无数量/字数/密度报警），**必须向用户汇报当前章节的撰写情况并询问是否继续**，得到用户明确批准后方可进入下一章节。
7. **文档修改机制**：如需对已排版的最终长文进行修改，**切勿直接修改带超链接的终版文档**。须先运行 `python scripts/revert_citations.py Review_Final_Formatted.md -o draft.md` 转回 `[PMID: xxx]` 格式。**此时需留意状态机输出的参考文献数量提示**，若提示文献数量不足（如 < 30篇），请在修改时一并带 `--post-write` 参数使用 `pubmed_search.py` 补充检索新文献，修改草稿后再重新运行格式化脚本。
8. 格式参考：`assets/Review_Final.md` 的正文章节部分

**详细说明**：

- 工作流程：[references/workflow-details.md](references/workflow-details.md) 第三阶段

- 引用规范：[references/citation-guide.md](references/citation-guide.md)

### 第四阶段：结论撰写

1. 回顾所有 `section_*.md` 文件  
2. 创建 `conclusion.md`：总结核心发现，呼应前言，展望未来 (⚠️ **不要包含引用**)
3. 格式参考：`assets/Review_Final.md` 的结论部分

**详细说明**：参见 [references/workflow-details.md](references/workflow-details.md) 第四阶段

### 第五阶段：摘要与定稿

1. 创建 `abstract.md`：
   - ⚠️ **必须包含综述标题**（参考 `assets/Review_Final.md` 格式）
   - 包含：背景、内容、发现、结论
   - ⚠️ **不要包含引用**
   - 5-7个关键词，使用中文分号（；）分隔
2. 合并定稿：`python scripts/merge_review.py abstract.md introduction.md section_1.md ... -o Review_Final.md` (⚠️ **注意**：不要包含 `outline.md`)
3. 格式核对：对比 `Review_Final.md` 和 `assets/Review_Final.md`

**详细说明**：参见 [references/workflow-details.md](references/workflow-details.md) 第五阶段

### 第六阶段：格式化引用

1. 运行：`python scripts/format_citations.py Review_Final.md -o Review_Final_Formatted.md`
2. 验证：检查引用链接和参考文献列表

**详细说明**：参见 [references/citation-guide.md](references/citation-guide.md)

## 核心原则

- **中间文件**：必须真实创建文件，不能只在内存中处理
- **引用规范**：仅使用 `[PMID: xxx]` 格式，方便后续脚本解析
- **语言**：默认使用中文撰写，专业术语可保留英文
- **严谨性**：前言和正文的每个观点都应有 `references.json` 中的文献支持
- **引用范围**：仅在**前言(Introduction)**和**正文(Body Sections)**中使用引用，**摘要(Abstract)**和**结论(Conclusion)**不使用引用
- **多样性**：单篇文献引用建议不超过 2 次（最多 3 次），尽量引用更多不同文献

## 资源文件

- **scripts/**: 自动化脚本（pubmed_search.py, merge_review.py, format_citations.py等）
- **assets/**: 输出模板（Review_Final.md）
- **references/**: 详细说明文档（workflow-details.md, citation-guide.md）

## Failure Handling

- 缺少关键输入时：明确指出缺少的字段、文件或标识符，并暂停继续。
- 脚本、模板或资源执行失败时：报告失败步骤、可能原因和恢复建议，不要静默降级。
- 只能部分完成时：先返回已验证部分，再列出剩余阻塞项和建议的下一步。

## Quick Validation

- 检查本 skill 依赖的关键脚本、模板或参考资料路径是否存在。
- 检查最终输出是否包含本任务约定的核心字段、章节或文件。
- 检查结果中是否清楚标注假设、限制和未完成项。
