---
name: journal-recommender
description: Recommend academic journals based on manuscript topic, abstract, and impact factor expectations. Use when the user wants to find suitable journals for their research manuscript, especially when they provide a topic, abstract, and target Impact Factor.
license: MIT
skill-author: AIPOCH
---

## Output Format

所有推荐结果必须严格按照以下三档表格输出，每个档位至少推荐 **5 个期刊**。

```
## 期刊推荐报告

### 推荐总览
| 推荐档位 | 期刊数 | 策略说明 |
|---------|:------:|---------|
| 🚀 冲刺 | N | 影响因子高于期望，需一定运气 |
| ✅ 稳健 | N | 影响因子匹配，命中率较高 |
| 🛡️ 保底 | N | 影响因子低于期望，几乎必中 |

### 🚀 冲刺期刊
| 期刊名 | 影响因子 | 审稿周期 | 录用率 | 匹配理由 | 预警风险 |
|-------|:-------:|:--------:|:-----:|---------|:--------:|
| Nature | 64.8 | 3-6月 | ~8% | 主题匹配度高 | ✅ 安全 |

### ✅ 稳健期刊
| 期刊名 | 影响因子 | 审稿周期 | 录用率 | 匹配理由 | 预警风险 |
|-------|:-------:|:--------:|:-----:|---------|:--------:|

### 🛡️ 保底期刊
| 期刊名 | 影响因子 | 审稿周期 | 录用率 | 匹配理由 | 预警风险 |
|-------|:-------:|:--------:|:-----:|---------|:--------:|

### ⚠️ 预警说明
列出已被列入预警名单的期刊（如果有），避免投稿。
```

# Journal Recommender

## Overview
This skill analyzes a research manuscript (topic, abstract, and optional full text) to extract key information (keywords, field, workload, innovation) and recommends journals in three categories: Sprint (High), Robust (Match), and Safe (Low).

## Workflow

1.  **Assess Manuscript**:
    *   Analyze the provided `topic` and `abstract`.
    *   Extract keywords and determine the specific research field.
    *   Evaluate the workload and innovation of the study.
    *   Estimate the manuscript's potential Impact Factor (IF).

2.  **Recommend Journals**:
    *   Based on the assessment and the user's `target_if`, search for and recommend journals.
    *   Categorize recommendations into:
        *   **Sprint Journals**: IF slightly higher than target (max +5).
        *   **Robust Journals**: IF matches the target and assessment.
        *   **Safe Journals**: IF lower than target, ensuring high acceptance chance.
    *   Ensure at least 5 journals per category.
    *   **Constraint**: Do not recommend journals from the CAS warning list.

## Usage

### Inputs
*   `topic` (Required): The title or topic of the manuscript.
*   `abstract` (Required): The abstract of the manuscript.
*   `target_if` (Required): The expected Impact Factor (number).
*   `manuscript` (Optional): Full text of the manuscript.
*   `article_type` (Default: "research article"): Type of the article.

### Deterministic Operations
*   **Sorting**: The recommended journals are sorted by Impact Factor in descending order using `scripts/journal_ranker.py`.

## Quality Rules
*   **IF Sorting**: Journals must be strictly sorted by IF.
*   **Safety**: No CAS warning journals are allowed.
*   **Quantity**: Minimum 5 journals per category.

## When to Use

- Use this skill when the request matches its documented task boundary.
- Use it when the user can provide the required inputs and expects a structured deliverable.
- Prefer this skill for repeatable, checklist-driven execution rather than open-ended brainstorming.

## When Not to Use

- Do not use this skill when the required source data, identifiers, files, or credentials are missing.
- Do not use this skill when the user asks for fabricated results, unsupported claims, or out-of-scope conclusions.
- Do not use this skill when a simpler direct answer is more appropriate than the documented workflow.

## Required Inputs

- A clearly specified task goal aligned with the documented scope.
- All required files, identifiers, parameters, or environment variables before execution.
- Any domain constraints, formatting requirements, and expected output destination if applicable.

## Output Contract

- Return a structured deliverable that is directly usable without reformatting.
- If a file is produced, prefer a deterministic output name such as `journal_recommender_result.md` unless the skill documentation defines a better convention.
- Include a short validation summary describing what was checked, what assumptions were made, and any remaining limitations.

## Validation and Safety Rules

- Validate required inputs before execution and stop early when mandatory fields or files are missing.
- Do not fabricate measurements, references, findings, or conclusions that are not supported by the provided source material.
- Emit a clear warning when credentials, privacy constraints, safety boundaries, or unsupported requests affect the result.
- Keep the output safe, reproducible, and within the documented scope at all times.

## Failure Handling

- If validation fails, explain the exact missing field, file, or parameter and show the minimum fix required.
- If an external dependency or script fails, surface the command path, likely cause, and the next recovery step.
- If partial output is returned, label it clearly and identify which checks could not be completed.

## Quick Validation

Run this minimal verification path before full execution when possible:

```bash
python scripts/journal_ranker.py --help
```

Expected output format:

```text
Result file: journal_recommender_result.md
Validation summary: PASS/FAIL with brief notes
Assumptions: explicit list if any
```

## User Checkpoints

- 在执行批量处理、覆盖文件、长耗时检索或多阶段生成前，先向用户确认范围和输出格式。
- 在关键判断存在歧义、证据不足或需要进入下一阶段前，先向用户确认是否继续。
