---
name: response-letter
description: Helps organize reviewer comments and generate a standardized Word (.docx) response letter that maps each change to its exact location (page/paragraph/line). Use when revising a manuscript, replying to peer-review feedback, or preparing internal review responses.
license: MIT
skill-author: AIPOCH
---

## When to Use

- You received peer-review comments and need a point-by-point response letter for journal resubmission.
- You must clearly map every manuscript change to a specific location (page/paragraph/line) for reviewers or editors.
- You need a consistent, professional response structure across multiple reviewers and revision rounds.
- You are coordinating an internal review and want a standardized change log and execution checklist.
- You need a Word (.docx) deliverable rather than a table-based response format.

## Key Features

- Consolidates, merges, and numbers reviewer comments across reviewers.
- Separates major vs. minor comments to prioritize revision work.
- Produces a fixed, repeatable response layout per comment:
  - **Reviewer’s Comment**
  - **Response**
  - **Changes in Text**
- Requires explicit change-location marking (page/paragraph/line) and version labeling.
- Supports quoting revised manuscript text (e.g., blockquotes) to make changes auditable.
- Generates a Word (.docx) response letter plus a modification/execution checklist.
- Adds an **Overview for the Editor** section summarizing major revisions at the beginning.
- Enforces a professional, polite tone throughout.

## Dependencies

- Microsoft Word `.docx` output (Word-compatible document generation)
- Reference format guide: `references/guide.md`

## Example Usage

```text
Input:
- Manuscript (tracked version or clean version + change notes)
- Reviewer comments (all reviewers, all rounds)
- Current manuscript pagination/line numbering scheme (if available)

Steps:
1) Organize comments
   - Merge all reviewer comments into a single list.
   - Number them sequentially (e.g., R1-1, R1-2…; R2-1…).
   - Tag each as Major or Minor.

2) Draft "Overview for the Editor"
   - Write one concise paragraph summarizing the major revisions and their rationale.

3) Write point-by-point responses
   For each numbered comment, output:
   - Reviewer’s Comment: (verbatim or lightly cleaned for clarity)
   - Response: (polite, direct, addresses the request)
   - Changes in Text: (what changed + where)

4) Mark locations and quote revised text
   - Provide page/paragraph/line for each change.
   - Specify additions/deletions.
   - Quote the revised paragraph when the main text is modified.

5) Generate deliverables
   - Export the full response letter as a Word document (.docx).
   - Produce a modification/execution checklist to verify all changes are applied.

Output (Word .docx structure):
- Title / Manuscript info (optional)
- Overview for the Editor
- Responses to Reviewer 1
  - R1-1
  - R1-2
  ...
- Responses to Reviewer 2
  ...
- Modification / Execution Checklist
```

## Implementation Details

- **Comment normalization and numbering**
  - Merge comments from all sources; assign stable IDs (e.g., `R{reviewer}-{index}`) to preserve traceability across revision rounds.
- **Major vs. minor classification**
  - Major: requests affecting study design, analyses, interpretation, or core claims.
  - Minor: wording, formatting, clarifications, citations, typos.
- **Per-comment fixed layout**
  - Each response must include three labeled blocks: *Reviewer’s Comment*, *Response*, *Changes in Text*.
- **Location marking**
  - Use page/paragraph/line when available; otherwise use section/subsection headings plus paragraph index.
  - Always indicate whether text was **added**, **deleted**, or **rewritten**.
- **Revised-text excerpting**
  - When the manuscript body changes, include the updated paragraph as an indented blockquote under *Changes in Text* for auditability.
- **Output constraints**
  - Final deliverable is a Word document (`.docx`).
  - Do not use table format for the response letter.
- **Formatting and checklists**
  - Follow `references/guide.md` for required output formats, checklist items, and key writing points.

## When Not to Use

- 缺少完成任务所必需的输入文件、标识符、参数或上下文时，不要继续，先要求用户补充。
- 用户要求超出本 skill 已声明范围的推断、外部操作或权限时，不要自行假设具备这些能力。
- 需要覆盖已有结果、执行高成本批量操作或扩大任务范围时，不要直接继续，先和用户确认。

## Required Inputs

| 字段 | 必填 | 格式/来源 | 示例 | 缺失时处理 |
|---|---|---|---|---|
| 用户任务说明 | 是 | 文本 | 研究问题、写作目标、分析目标 | 缺失时停止并要求补充 |
| 主要输入材料 | 视任务而定 | 文本、文件路径、ID、表格或文献 | PMID、PDF、CSV、DOCX、主题词等 | 明确指出缺少哪类材料 |
| 输出偏好 | 否 | 文本 | 语言、格式、目标期刊、模板 | 未提供时采用 skill 默认格式 |

## Output Contract

- 主输出：与本 skill 目标一致的结构化结果或目标文件。
- 可选输出：中间检查说明、问题清单、补充建议或生成文件路径。
- 格式要求：除非用户另有要求，优先返回稳定、可复核的 Markdown 或 JSON；若 skill 自带脚本要求固定格式，则按该格式输出。
- 若为部分完成：必须显式标注 PARTIAL，并说明哪些步骤已完成、哪些步骤未完成。

## Failure Handling

- 缺少关键输入时：明确指出缺少的字段、文件或标识符，并暂停继续。
- 脚本、模板或资源执行失败时：报告失败步骤、可能原因和恢复建议，不要静默降级。
- 只能部分完成时：先返回已验证部分，再列出剩余阻塞项和建议的下一步。

## User Checkpoints

- 在执行批量处理、覆盖文件、长耗时检索或多阶段生成前，先向用户确认范围和输出格式。
- 在关键判断存在歧义、证据不足或需要进入下一阶段前，先向用户确认是否继续。

## Quick Validation

- 检查本 skill 依赖的关键脚本、模板或参考资料路径是否存在。
- 检查最终输出是否包含本任务约定的核心字段、章节或文件。
- 检查结果中是否清楚标注假设、限制和未完成项。
