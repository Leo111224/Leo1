---
name: diagnostic-study-quality-assessment-quadas-2
description: Analyzes clinical diagnostic accuracy studies for bias using the QUADAS-2 tool. Use when Claude needs to assess the quality, risk of bias, or applicability of diagnostic accuracy studies (e.g., "Assess this paper using QUADAS-2").
license: MIT
skill-author: AIPOCH
---

# Clinical Study Bias Assessment (QUADAS-2)

This skill evaluates clinical diagnostic accuracy studies for bias and applicability concerns using the Quality Assessment of Diagnostic Accuracy Studies-2 (QUADAS-2) tool.

## Workflow

To assess a study, follow these steps:

1.  **Analyze Patient Selection**:
    *   Assess if the sample was consecutive or random.
    *   Check for case-control design (should be avoided).
    *   Check for inappropriate exclusions.
    *   See `references/quadas_2_criteria.md` for detailed signaling questions.

2.  **Analyze Index Test**:
    *   Assess if the index test results were interpreted without knowledge of the reference standard.
    *   Check if the threshold was pre-specified.

3.  **Analyze Reference Standard**:
    *   Assess if the reference standard correctly classifies the target condition.
    *   Check if reference standard results were interpreted without knowledge of the index test.

4.  **Analyze Flow and Timing**:
    *   Assess the interval between index test and reference standard.
    *   Check if all patients received the reference standard (and the same one).
    *   Check if all patients were included in the analysis.

## Output Format

For each domain (Patient Selection, Index Test, Reference Standard, Flow and Timing), you MUST output the findings in the following structure:

```markdown
### [Domain Name]

**[Signaling Question 1]?**
- Comments: [Explanation in Chinese]
- Quote: [Original text quote]
- Answer: [Yes/No/Unclear]

... (Repeat for all signaling questions)
```

## Quality Rules

1.  **Language**: Explanations (Comments) must be in Chinese.
2.  **Evidence**: Every judgment must be supported by a direct quote from the paper.
3.  **Strictness**: If information is missing, select "Unclear". Do not guess.

## PDF Parsing Tool

For processing PDF literature, you can use the provided Python script:

```bash
# Install dependencies
pip install PyPDF2

# Extract full text
python scripts/pdf_extractor.py "paper.pdf"

# Extract specific page range
python scripts/pdf_extractor.py "paper.pdf" 5 15
```

The script will automatically extract the text, which you can then copy and send to me for QUADAS-2 assessment.

## References

-   [QUADAS-2 Criteria](references/quadas_2_criteria.md): Detailed signaling questions and judgment guidelines.

## When to Use

- 当用户明确需要执行 diagnostic-study-quality-assessment-quadas-2 对应的核心任务，并且已经提供最小可执行输入时使用。
- 当你需要结构化交付物，而不是仅提供泛泛建议时使用。
- 当当前任务可以通过本 skill 自带的脚本、模板或参考资料完成时使用。

## When Not to Use

- 缺少完成任务所必需的输入文件、标识符、参数或上下文时，不要继续，先要求用户补充。
- 用户要求超出本 skill 已声明范围的推断、外部操作或权限时，不要自行假设具备这些能力。
- 需要覆盖已有结果、执行高成本批量操作或扩大任务范围时，不要直接继续，先和用户确认。

## Required Inputs

| 字段 | 必填 | 格式/来源 | 示例 | 缺失时处理 |
|---|---|---|---|---|
| 用户任务说明 | 是 | 文本 | 研究问题、写作目标、分析目标 | 缺失时停止并要求补充 |
| 主要输入材料 | 视任务而定 | 文本、文件路径、ID、表格或文献 | PMID、PDF、CSV、DOCX、主题词等 | 明确指出缺少哪类材料 |
| 输出偏好 | 否 | 文本 | 语言、格式、目标期刊、模板 | 未提供时采用 skill 默认格式 |

## Output Contract

- 主输出：与本 skill 目标一致的结构化结果或目标文件。
- 可选输出：中间检查说明、问题清单、补充建议或生成文件路径。
- 格式要求：除非用户另有要求，优先返回稳定、可复核的 Markdown 或 JSON；若 skill 自带脚本要求固定格式，则按该格式输出。
- 若为部分完成：必须显式标注 PARTIAL，并说明哪些步骤已完成、哪些步骤未完成。

## Failure Handling

- 缺少关键输入时：明确指出缺少的字段、文件或标识符，并暂停继续。
- 脚本、模板或资源执行失败时：报告失败步骤、可能原因和恢复建议，不要静默降级。
- 只能部分完成时：先返回已验证部分，再列出剩余阻塞项和建议的下一步。

## User Checkpoints

- 在执行批量处理、覆盖文件、长耗时检索或多阶段生成前，先向用户确认范围和输出格式。
- 在关键判断存在歧义、证据不足或需要进入下一阶段前，先向用户确认是否继续。

## Quick Validation

- 检查本 skill 依赖的关键脚本、模板或参考资料路径是否存在。
- 检查最终输出是否包含本任务约定的核心字段、章节或文件。
- 检查结果中是否清楚标注假设、限制和未完成项。
