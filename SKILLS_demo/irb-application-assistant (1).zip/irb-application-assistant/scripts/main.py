#!/usr/bin/env python3
"""
IRB Application Assistant
Draft IRB applications with focus on risk/benefit and privacy protection.
"""

import argparse
from datetime import datetime


class IRBAssistant:
    """Assist with IRB application drafting."""
    
    def generate_application(self, study_info):
        """Generate IRB application sections."""
        sections = []
        
        # Protocol Summary
        sections.append("="*70)
        sections.append("IRB APPLICATION")
        sections.append("="*70)
        sections.append("")
        sections.append("1. PROTOCOL SUMMARY")
        sections.append("-"*70)
        sections.append(f"Title: {study_info.get('title', '[Study Title]')}")
        sections.append(f"Principal Investigator: {study_info.get('pi', '[PI Name]')}")
        sections.append(f"Institution: {study_info.get('institution', '[Institution]')}")
        sections.append("")
        sections.append(f"Study Purpose: {study_info.get('purpose', '[Brief description of study purpose]')}")
        sections.append("")
        
        # Study Procedures
        sections.append("2. STUDY PROCEDURES")
        sections.append("-"*70)
        sections.append("2.1 Subject Population")
        sections.append(f"  Target population: {study_info.get('population', '[Description]')}")
        sections.append(f"  Number of subjects: {study_info.get('n_subjects', '[N]')}")
        sections.append(f"  Inclusion criteria: {study_info.get('inclusion', '[Criteria]')}")
        sections.append(f"  Exclusion criteria: {study_info.get('exclusion', '[Criteria]')}")
        sections.append("")
        
        sections.append("2.2 Study Procedures")
        sections.append(f"  {study_info.get('procedures', '[Describe all study procedures]')}")
        sections.append("")
        
        # Risk Assessment
        sections.append("3. RISK/BENEFIT ASSESSMENT")
        sections.append("-"*70)
        sections.append("3.1 Risks")
        risks = study_info.get('risks', [])
        if risks:
            for risk in risks:
                sections.append(f"  • {risk}")
        else:
            sections.append("  • [List all potential risks]")
        sections.append("")
        
        sections.append("3.2 Risk Minimization")
        sections.append("  [Describe measures to minimize risks]")
        sections.append("")
        
        sections.append("3.3 Benefits")
        benefits = study_info.get('benefits', [])
        if benefits:
            for benefit in benefits:
                sections.append(f"  • {benefit}")
        else:
            sections.append("  • [List potential benefits]")
        sections.append("")
        
        sections.append("3.4 Risk/Benefit Justification")
        sections.append("  [Explain why benefits justify the risks]")
        sections.append("")
        
        # Privacy Protection
        sections.append("4. PRIVACY AND CONFIDENTIALITY")
        sections.append("-"*70)
        sections.append("4.1 Data Collection")
        sections.append("  [Describe what data will be collected and how]")
        sections.append("")
        
        sections.append("4.2 Data Storage")
        sections.append("  • Identifiers will be stored separately from data")
        sections.append("  • Data will be stored in secure, encrypted location")
        sections.append("  • Access limited to authorized study personnel")
        sections.append("")
        
        sections.append("4.3 Data Sharing")
        sections.append("  [Describe plans for data sharing, if any]")
        sections.append("")
        
        sections.append("4.4 Retention and Disposal")
        sections.append("  • Data will be retained for [X] years post-study")
        sections.append("  • Secure disposal procedures will be followed")
        sections.append("")
        
        # Consent Process
        sections.append("5. INFORMED CONSENT")
        sections.append("-"*70)
        sections.append("  [Describe consent process and documents]")
        sections.append("")
        
        sections.append("="*70)
        
        return "\n".join(sections)
    
    def generate_consent_template(self, study_info):
        """Generate detailed informed consent form template (v1.1.0)."""
        template = []
        
        template.append("="*70)
        template.append("INFORMED CONSENT FORM — IRB v1.1.0 Template")
        template.append("="*70)
        template.append("")
        template.append(f"STUDY TITLE: {study_info.get('title', '[Study Title]')}")
        template.append(f"PRINCIPAL INVESTIGATOR: {study_info.get('pi', '[PI Name]')}")
        template.append(f"INSTITUTION: {study_info.get('institution', '[Institution]')}")
        template.append(f"STUDY SPONSOR/FUNDING: {study_info.get('sponsor', '[Sponsor]')}")
        template.append("")
        template.append("─"*70)
        template.append("1. PURPOSE OF THE STUDY")
        template.append("─"*70)
        template.append("You are being asked to take part in a research study. ")
        template.append("Before you decide whether to participate, it is important that you understand ")
        template.append("why the research is being done, what it will involve, and the potential risks and benefits.")
        template.append("")
        template.append(study_info.get('purpose', '[Study purpose - plain language description]'))
        template.append("")
        
        template.append("─"*70)
        template.append("2. STUDY PROCEDURES")
        template.append("─"*70)
        template.append("If you agree to take part in this study, the following procedures will occur:")
        template.append("")
        template.append(study_info.get('procedures', '[Numbered list of study procedures]'))
        template.append("")
        template.append(f"Number of participants: {study_info.get('n_subjects', '[N]')}")
        template.append("")
        
        template.append("─"*70)
        template.append("3. RISKS AND DISCOMFORTS")
        template.append("─"*70)
        risks = study_info.get('risks', [])
        if risks:
            template.append("The following risks are associated with this study:")
            for i, risk in enumerate(risks, 1):
                template.append(f"  {i}. {risk}")
        else:
            template.append("[List all potential risks, their likelihood, and severity]")
        template.append("")
        template.append("Risk minimization measures: [Describe measures to minimize each risk]")
        template.append("")
        
        template.append("─"*70)
        template.append("4. POTENTIAL BENEFITS")
        template.append("─"*70)
        benefits = study_info.get('benefits', [])
        if benefits:
            template.append("Possible benefits of participating in this study include:")
            for benefit in benefits:
                template.append(f"  • {benefit}")
        template.append("")
        template.append("Note: There may be no direct benefit to you from participating.")
        template.append("")
        
        template.append("─"*70)
        template.append("5. ALTERNATIVES")
        template.append("─"*70)
        template.append("Your alternative is to not participate in this study.")
        template.append("[Describe any specific alternatives if applicable, e.g., standard treatment options]")
        template.append("")
        
        template.append("─"*70)
        template.append("6. CONFIDENTIALITY")
        template.append("─"*70)
        template.append("Your privacy and the confidentiality of your data will be protected to the fullest extent possible.")
        template.append("")
        template.append("  • Your records and data will be coded with a unique study ID")
        template.append("  • The master list linking your identity to your study ID will be stored separately")
        template.append("  • All data will be stored on secure, encrypted servers")
        template.append("  • Access to your data will be limited to authorized study personnel")
        template.append("  • Your information may be shared with: [regulatory agencies, sponsors, data monitoring committees]")
        template.append("  • Results may be published, but your identity will not be disclosed")
        template.append("")
        template.append(f"Data retention period: [X] years after study completion")
        template.append("")
        
        template.append("─"*70)
        template.append("7. COMPENSATION AND COSTS")
        template.append("─"*70)
        template.append("[Describe any payment, reimbursement for travel, or compensation for time]")
        template.append("[Describe any costs to the participant]")
        template.append("[Describe compensation for research-related injury if applicable]")
        template.append("")
        
        template.append("─"*70)
        template.append("8. VOLUNTARY PARTICIPATION AND WITHDRAWAL")
        template.append("─"*70)
        template.append("Your participation in this study is completely voluntary.")
        template.append("You may choose not to participate, or you may withdraw at any time")
        template.append("without penalty or loss of benefits to which you are otherwise entitled.")
        template.append("")
        template.append("If you withdraw: [Describe consequences, data retention/removal policy]")
        template.append("If you choose not to participate: [Describe effect on care/services]")
        template.append("")
        
        template.append("─"*70)
        template.append("9. CONTACT INFORMATION")
        template.append("─"*70)
        template.append("For questions about the study:            [PI Name, Phone, Email]")
        template.append("For questions about your rights:           [IRB Office, Phone]")
        template.append("For research-related injury:              [Contact, Phone]")
        template.append("")
        
        template.append("─"*70)
        template.append("10. SIGNATURES")
        template.append("─"*70)
        template.append("")
        template.append("I have read the above information (or it has been read to me).")
        template.append("I have had the opportunity to ask questions and they have been answered to my satisfaction.")
        template.append("I voluntarily agree to participate in this research study.")
        template.append("")
        template.append("________________________________________")
        template.append("Participant Name (print)                        Date")
        template.append("")
        template.append("________________________________________")
        template.append("Participant Signature                           Date")
        template.append("")
        template.append("________________________________________")
        template.append("Person Obtaining Consent (print)                Date")
        template.append("")
        template.append("________________________________________")
        template.append("Person Obtaining Consent Signature              Date")
        template.append("")
        template.append("="*70)
        template.append("END OF CONSENT FORM")
        template.append("="*70)
        
        return "\n".join(template)


def main():
    parser = argparse.ArgumentParser(description="IRB Application Assistant")
    parser.add_argument("--title", "-t", help="Study title")
    parser.add_argument("--pi", help="Principal Investigator")
    parser.add_argument("--population", "-p", help="Target population")
    parser.add_argument("--n-subjects", "-n", help="Number of subjects")
    parser.add_argument("--output", "-o", default="irb_application.txt", help="Output file")
    parser.add_argument("--template", action="store_true", help="Generate consent template")
    parser.add_argument("--sponsor", "-s", help="Study sponsor / funding source")
    
    args = parser.parse_args()
    
    assistant = IRBAssistant()
    
    study_info = {
        "title": args.title or "[Study Title]",
        "pi": args.pi or "[PI Name]",
        "population": args.population or "[Target population]",
        "n_subjects": args.n_subjects or "[N]",
        "sponsor": args.sponsor or "[Sponsor]",
        "institution": "[Institution]",
        "purpose": "[Study purpose]",
        "procedures": "[Study procedures]",
        "risks": ["Minimal risk procedures"],
        "benefits": ["Contribution to scientific knowledge"]
    }
    
    if args.template:
        text = assistant.generate_consent_template(study_info)
    else:
        text = assistant.generate_application(study_info)
    
    print(text)
    
    with open(args.output, 'w') as f:
        f.write(text)
    print(f"\nSaved to: {args.output}")


if __name__ == "__main__":
    main()
