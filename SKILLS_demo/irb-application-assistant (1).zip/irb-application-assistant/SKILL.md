---
name: irb-application-assistant
description: Assists researchers with Institutional Review Board (IRB) application tasks, including drafting informed consent documents, reviewing research protocols for compliance, generating application forms, and preparing submission checklists.
license: MIT
skill-author: AIPOCH
---
# IRB Application Assistant

Helps researchers prepare, review, and submit Institutional Review Board (IRB) applications. Supports drafting informed consent templates, checking protocol compliance, generating application documents, and guiding researchers through the submission workflow.

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
```

## When to Use

- Drafting informed consent documents for IRB submission
- Running compliance checks on research protocols
- Generating IRB application packages (initial review, continuing review, amendment)
- Validating submission completeness before IRB filing

## Workflow

1. **Prepare study configuration** — Input: study title, PI details, participant population, risk level, procedures → populate `study_config.json` → Output: structured study config file
2. **Run compliance check** — Execute `--task compliance-check` against protocol → identify gaps in required sections (purpose, procedures, risks, benefits, confidentiality) → ⛔ Checkpoint: If compliance report flags ANY errors → resolve ALL items and re-run before proceeding → Output: clean compliance report
3. **Generate consent document** — Execute `--task consent` with protocol and population parameters → produce informed consent at appropriate reading level → Output: consent form draft
4. **Generate application forms** — Execute `--task generate-application` with form type (initial-review/continuing-review/amendment) → Output: IRB application forms
5. **Validate submission package** — Execute `--task validate-submission` → check all required documents present and fields complete → ⛔ Checkpoint: If validation fails → fix errors → re-run validation → only proceed with zero blocking errors → Output: validated submission package
6. **Final review** — Manually review remaining warnings → confirm consent language readability → submit to IRB → Output: submission-ready package

## Quick Start

```text
# Generate an informed consent template
python scripts/main.py --task consent --protocol protocol.json --output consent_form.docx

# Run a compliance check on a research protocol
python scripts/main.py --task compliance-check --protocol protocol.json --verbose

# Generate a full IRB application package
python scripts/main.py --task generate-application --config study_config.json --output irb_package/
```

## Core Capabilities

### 1. Generate Informed Consent Documents

Produces compliant informed consent forms based on study parameters such as participant population, risk level, and study type.

```text
python scripts/main.py --task consent \
  --protocol protocol.json \
  --population "adults 18+" \
  --risk-level minimal \
  --output consent_form.docx
```

### 2. Protocol Compliance Review

Checks a research protocol against IRB requirements and flags missing or non-compliant sections.

```text
python scripts/main.py --task compliance-check \
  --protocol protocol.json \
  --ruleset federal-common-rule \
  --output compliance_report.txt
```

### 3. Application Form Generation

Generates completed IRB application forms (e.g., initial review, continuing review, amendment) from structured study data.

```text
python scripts/main.py --task generate-application \
  --form-type initial-review \
  --config study_config.json \
  --output irb_application.docx
```

### 4. Submission Checklist Validation

Validates that all required documents and fields are present before submission.

```text
python scripts/main.py --task validate-submission \
  --package irb_package/ \
  --output validation_report.txt
```

## Recommended Workflow

Follow these steps for a complete IRB submission:

1. **Prepare study configuration** — Populate `study_config.json` with study title, PI details, participant population, risk level, and procedures.
2. **Run compliance check** — Use `--task compliance-check` to identify gaps in the protocol before drafting documents.
   - ⛔ **Checkpoint**: If the compliance report flags ANY errors, resolve ALL flagged items and re-run `--task compliance-check` before proceeding. Do not advance to step 3 with unresolved compliance errors.
3. **Generate consent document** — Use `--task consent` to produce a compliant informed consent form tailored to the study.
4. **Generate application forms** — Use `--task generate-application` to produce the required IRB submission forms.
5. **Validate submission package** — Use `--task validate-submission` to confirm all required documents are present and fields are complete.
   - ⛔ **Checkpoint**: If validation fails, follow this loop: review errors in `validation_report.txt` → fix each issue → re-run `--task validate-submission` → only proceed when the report shows zero blocking errors.
6. **Review and submit** — Manually review any remaining warnings in the compliance and validation reports before submitting to the IRB.

## IRB Submission Checklist (v1.1.0)

### Required Documents — Pre-Submission Verification

Before any IRB submission, verify each item below. The output must report the status of each applicable item.

| Document Category | Specific Item | Status (Present/Missing/NA) | Notes |
|---|---|---|---|
| **Core Application** | IRB application form (initial review) | | |
| | Protocol / research plan | | |
| | Informed consent form(s) | | |
| | HIPAA authorization (if applicable) | | |
| | PI assurances / signatures | | |
| | Institutional sign-off | | |
| **Consent Materials** | Consent form — standard version | | |
| | Consent form — LAR/legally authorized representative version (if applicable) | | |
| | Consent form — pediatric assent (if applicable) | | |
| | Consent form — non-English translations (if applicable) | | |
| | Consent form — short form (if applicable) | | |
| | Waiver of consent documentation request (if applicable) | | |
| | Waiver of consent request (if applicable) | | |
| **Recruitment Materials** | Recruitment flyers, posters, or brochures | | |
| | Email scripts / phone scripts | | |
| | Social media post text (if used) | | |
| | Referral scripts for physicians | | |
| **Study Instruments** | Surveys / questionnaires | | |
| | Interview guides / focus group guides | | |
| | Data collection forms / CRFs | | |
| | Data management plan | | |
| **Safety & Monitoring** | Data Safety Monitoring Board (DSMB) plan (if applicable) | | |
| | Adverse event reporting plan | | |
| | Safety monitoring reports (for continuing review) | | |
| | Investigator Brochure (for drug/device studies) | | |
| | FDA IND/IDE number (if applicable) | | |
| **Regulatory** | CV / biosketch for PI and key personnel | | |
| | Human subjects training certificates (CITI or equivalent) | | |
| | Conflict of interest disclosure | | |
| | Grant proposal / funding source documentation | | |
| | Multi-site reliance agreement (if applicable) | | |
| | External site IRB authorization (if applicable) | | |
| | ClinicalTrials.gov registration (if applicable) | | |

### Consent Form Content Checklist — 21 CFR 50.25 / ICH GCP E6(R2)

| Required Element | Present? | Location in Document |
|---|---|---|
| [ ] Statement that study involves research | | |
| [ ] Purpose of the research | | |
| [ ] Duration of participation | | |
| [ ] Description of procedures | | |
| [ ] Identification of experimental procedures | | |
| [ ] Foreseeable risks or discomforts | | |
| [ ] Expected benefits (to subject or others) | | |
| [ ] Alternative procedures or treatments | | |
| [ ] Confidentiality of records | | |
| [ ] Compensation for injury (if > minimal risk) | | |
| [ ] Contact information for questions | | |
| [ ] Contact for research-related injury | | |
| [ ] Voluntary participation statement | | |
| [ ] Right to withdraw at any time | | |
| [ ] Consequences of withdrawal | | |
| [ ] Number of subjects | | |
| [ ] HIPAA research authorization (if applicable) | | |
| [ ] Statement about biospecimen use/storage (if applicable) | | |
| [ ] Commercial use of specimens (if applicable) | | |
| [ ] Whole genome sequencing disclosure (if applicable) | | |

### Submission Routing Decision

| IRB Type | When to Use |
|---|---|
| **Exempt** | Minimal risk, no sensitive data, standard educational/survey/interview procedures |
| **Expedited** | Minimal risk but involves identifiable data, blood draws, non-invasive imaging, or moderate procedures |
| **Full Board** | > Minimal risk, vulnerable populations, drug/device studies, invasive procedures |
| **Continuing Review** | Annual renewal of approved protocols |
| **Amendment** | Changes to approved protocols (personnel, procedures, consent, population) |

## Informed Consent Form Template (v1.1.0)

When generating consent forms, use the following structured template with placeholders automatically filled from the study configuration:

```text
**STUDY TITLE:** [Title from config]

**PRINCIPAL INVESTIGATOR:** [PI Name], [Department], [Phone], [Email]

**FUNDING SOURCE:** [Funding agency]

**1. PURPOSE OF THE STUDY**
You are being asked to take part in a research study. Before you decide, it is important for you to understand why the research is being done and what it will involve.
[Brief plain-language description of study purpose]

**2. STUDY PROCEDURES**
If you agree to take part, here is what will happen:
[Numbered list of procedures with duration estimates]

**3. NUMBER OF PARTICIPANTS**
Approximately [N] people will take part in this study at [sites].

**4. DURATION OF PARTICIPATION**
Your participation will last approximately [time period].

**5. RISKS AND DISCOMFORTS**
[List each risk with likelihood and severity rating]

**6. BENEFITS**
You may not directly benefit from this study. [Describe potential benefits or state "This study may help future patients."]

**7. ALTERNATIVES**
[Describe alternatives or state "Your alternative is not to participate."]

**8. CONFIDENTIALITY**
Your records will be kept private. [Describe data security, who will have access, and data sharing plans]

**9. COMPENSATION AND COSTS**
[Describe payment, reimbursement, or state there is none]

**10. VOLUNTARY PARTICIPATION AND WITHDRAWAL**
Taking part is voluntary. You may skip any questions or stop at any time. If you withdraw, [describe consequences if any].

**11. CONTACT INFORMATION**
For questions about the study: [PI contact]
For questions about your rights: [IRB office contact]
For research-related injury: [contact]
```

## Quality Checklist

- [ ] Protocol includes all required sections (purpose, procedures, risks, benefits, confidentiality)
- [ ] Informed consent language is at appropriate reading level for participant population
- [ ] Risk level classification is justified and documented
- [ ] All required attachments (recruitment materials, surveys, data management plan) are included
- [ ] Compliance report reviewed and all flagged items resolved
- [ ] Submission package validated with zero blocking errors

## References

- `references/guide.md` — Detailed documentation and field descriptions
- `references/examples/` — Sample protocols, consent forms, and completed applications

---

**Skill ID**: 952 | **Version**: 1.0 | **License**: MIT

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `irb-application-assistant` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `irb-application-assistant` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.


## References

- [references/audit-reference.md](references/audit-reference.md) - Supported scope, audit commands, and fallback boundaries

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.
