#!/usr/bin/env python3
"""
Patient Consent Simplifier
Simplify informed consent forms to plain language.
"""

import argparse
import re


class ConsentSimplifier:
    """Simplify consent form language."""
    
    # Common legal/medical term replacements
    REPLACEMENTS = {
        "hereby": "now",
        "hereinafter": "from now on",
        "aforementioned": "mentioned above",
        "indemnify": "protect from harm",
        "liability": "legal responsibility",
        "thereto": "to it",
        "whereas": "because",
        "witnesseth": "shows that",
        "pursuant to": "under",
        "notwithstanding": "even if",
        "prospective": "future",
        "voluntary": "by choice",
        "confidentiality": "privacy",
        "randomization": "random assignment",
        "placebo": "inactive substance",
        "adverse event": "side effect",
        "investigational": "experimental"
    }
    
    def simplify(self, text):
        """Simplify consent form text."""
        simplified = text
        
        # Replace complex terms
        for term, replacement in self.REPLACEMENTS.items():
            simplified = re.sub(r'\b' + term + r'\b', replacement, simplified, flags=re.IGNORECASE)
        
        # Break long sentences (simple heuristic)
        sentences = simplified.split(". ")
        shortened = []
        for sent in sentences:
            if len(sent.split()) > 25:
                # Try to break at conjunctions
                sent = re.sub(r',\s*and\s+', ". Also, ", sent)
                sent = re.sub(r';\s*', ". ", sent)
            shortened.append(sent)
        
        simplified = ". ".join(shortened)
        
        # Calculate readability (simple word count heuristic)
        words = text.split()
        avg_sentence_len = len(words) / max(len(sentences), 1)
        
        return {
            "original": text,
            "simplified": simplified,
            "original_word_count": len(words),
            "simplified_word_count": len(simplified.split()),
            "avg_sentence_length": avg_sentence_len,
            "terms_replaced": len(self.REPLACEMENTS)
        }
    
    def calculate_grade_level(self, text):
        """Estimate Flesch-Kincaid grade level."""
        sentences = max(len(text.split(". ")), 1)
        words = len(text.split())
        syllables = sum(self._count_syllables(w) for w in text.split())
        
        if words == 0:
            return 0
        
        # Flesch-Kincaid Grade Level formula
        grade = 0.39 * (words / sentences) + 11.8 * (syllables / words) - 15.59
        return max(0, round(grade, 1))
    
    def calculate_flesch_reading_ease(self, text):
        """Calculate Flesch Reading Ease score (v1.1.0)."""
        sentences = max(len(text.split(". ")), 1)
        words = len(text.split())
        syllables = sum(self._count_syllables(w) for w in text.split())
        
        if words == 0 or sentences == 0:
            return 0
        
        # Flesch Reading Ease formula
        score = 206.835 - 1.015 * (words / sentences) - 84.6 * (syllables / words)
        return round(max(0, min(score, 100)), 1)
    
    def interpret_readability(self, fre_score):
        """Interpret Flesch Reading Ease score (v1.1.0)."""
        if fre_score >= 90:
            return "Very Easy — conversational, suitable for 4th grade"
        elif fre_score >= 80:
            return "Easy — suitable for 5th grade"
        elif fre_score >= 70:
            return "Fairly Easy — suitable for 6th grade"
        elif fre_score >= 60:
            return "Standard — plain English, target for consent forms"
        elif fre_score >= 50:
            return "Fairly Difficult — suitable for 9th–10th grade"
        elif fre_score >= 30:
            return "Difficult — academic level"
        else:
            return "Very Confusing — highly technical, unsuitable for consent"
    
    def assess_readability_full(self, text):
        """Comprehensive readability assessment (v1.1.0)."""
        sentences = [s.strip() for s in text.split(". ") if s.strip()]
        words = text.split()
        syllables = sum(self._count_syllables(w) for w in words)
        
        if not words or not sentences:
            return {}
        
        n_sentences = len(sentences)
        n_words = len(words)
        
        # Calculate metrics
        fre = self.calculate_flesch_reading_ease(text)
        fk_grade = self.calculate_grade_level(text)
        avg_words_per_sentence = n_words / max(n_sentences, 1)
        avg_syllables_per_word = syllables / max(n_words, 1)
        
        # Count complex words (3+ syllables)
        complex_words = sum(1 for w in words if self._count_syllables(w) >= 3)
        pct_complex = (complex_words / max(n_words, 1)) * 100
        
        # Count passive voice indicators (simple heuristic: "be" + past participle patterns)
        passive_count = 0
        for i, w in enumerate(words):
            w_lower = w.lower().strip(".,!?;\"'")
            if w_lower in ("is", "are", "was", "were", "been", "being", "am") and i + 1 < len(words):
                next_word = words[i + 1].lower().strip(".,!?;\"'")
                if next_word.endswith("ed") or next_word.endswith("en") or next_word.endswith("t"):
                    passive_count += 1
        
        return {
            "flesch_reading_ease": fre,
            "flesch_reading_ease_interpretation": self.interpret_readability(fre),
            "fk_grade_level": fk_grade,
            "avg_words_per_sentence": round(avg_words_per_sentence, 1),
            "avg_syllables_per_word": round(avg_syllables_per_word, 2),
            "complex_word_pct": round(pct_complex, 1),
            "passive_voice_count": passive_count,
            "total_sentences": n_sentences,
            "total_words": n_words,
            "total_syllables": syllables
        }
    
    def _count_syllables(self, word):
        """Rough syllable count."""
        word = word.lower().strip(".,!?;")
        if not word:
            return 0
        vowels = "aeiouy"
        count = 0
        prev_was_vowel = False
        for char in word:
            if char in vowels:
                if not prev_was_vowel:
                    count += 1
                prev_was_vowel = True
            else:
                prev_was_vowel = False
        if word.endswith("e"):
            count -= 1
        return max(1, count)


def main():
    parser = argparse.ArgumentParser(description="Patient Consent Simplifier")
    parser.add_argument("--input", "-i", help="Input consent form file")
    parser.add_argument("--text", "-t", help="Direct text input")
    parser.add_argument("--output", "-o", help="Output file")
    parser.add_argument("--target-grade", type=int, default=5, help="Target reading grade")
    
    args = parser.parse_args()
    
    simplifier = ConsentSimplifier()
    
    if args.input:
        with open(args.input) as f:
            text = f.read()
    elif args.text:
        text = args.text
    else:
        # Demo text
        text = """You hereby authorize the investigators to conduct research procedures 
        as described in the aforementioned protocol. You understand that participation 
        is voluntary and you may withdraw at any time without prejudice."""
    
    result = simplifier.simplify(text)
    original_grade = simplifier.calculate_grade_level(text)
    simplified_grade = simplifier.calculate_grade_level(result["simplified"])
    
    # v1.1.0: Enhanced readability assessment
    original_readability = simplifier.assess_readability_full(text)
    simplified_readability = simplifier.assess_readability_full(result["simplified"])
    
    print("\n" + "="*60)
    print("CONSENT FORM SIMPLIFICATION")
    print("="*60)
    print(f"\n--- READABILITY REPORT (v1.1.0) ---")
    print(f"\nOriginal:")
    print(f"  Flesch Reading Ease:      {original_readability['flesch_reading_ease']}")
    print(f"    → {original_readability['flesch_reading_ease_interpretation']}")
    print(f"  Flesch-Kincaid Grade:     {original_grade}")
    print(f"  Avg words/sentence:       {original_readability['avg_words_per_sentence']}")
    print(f"  Complex words:            {original_readability['complex_word_pct']}%")
    print(f"  Passive voice count:      {original_readability['passive_voice_count']}")
    print(f"\nSimplified:")
    print(f"  Flesch Reading Ease:      {simplified_readability['flesch_reading_ease']}")
    print(f"    → {simplified_readability['flesch_reading_ease_interpretation']}")
    print(f"  Flesch-Kincaid Grade:     {simplified_grade}")
    print(f"  Avg words/sentence:       {simplified_readability['avg_words_per_sentence']}")
    print(f"  Complex words:            {simplified_readability['complex_word_pct']}%")
    print(f"  Passive voice count:      {simplified_readability['passive_voice_count']}")
    target = args.target_grade
    target_range = "✓ WITHIN TARGET RANGE" if simplified_grade <= target else f"✗ ABOVE TARGET (target: ≤{target})"
    print(f"  Target grade: {target} | Status: {target_range}")
    print(f"  Word Count: {result['original_word_count']} → {result['simplified_word_count']}")
    print("\n--- SIMPLIFIED VERSION ---\n")
    print(result["simplified"])
    print("\n" + "="*60)
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write(result["simplified"])
        print(f"\nSaved to: {args.output}")


if __name__ == "__main__":
    main()
