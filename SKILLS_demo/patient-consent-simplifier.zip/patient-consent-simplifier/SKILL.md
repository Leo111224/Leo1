---
name: patient-consent-simplifier
description: Simplifies informed consent documents into patient-friendly language while maintaining regulatory compliance. Readability assessment targeting 6th-8th grade level, risk/benefit clarification in table format, and FDA 21CFR50/ICH-GCP/HIPAA compliance validation.
license: MIT
skill-author: AIPOCH
---
# Patient Consent Simplifier

Transform complex informed consent documents into patient-friendly language while maintaining regulatory compliance and ethical standards.

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
python scripts/main.py --text "Audit validation sample with explicit methods, findings, and conclusion."
```

## When to Use

- Use this skill when simplifying informed consent documents or translating medical procedures for patients.
- Use this skill when creating patient-friendly research summaries or adapting clinical trial information for lay audiences.
- Use this skill when the user says "simplify consent", "plain language consent", or "patient-friendly consent form".

## Workflow

1. **Receive document and target**: Collect the consent document text and confirm target reading level (default: 8th grade for general population; 6th grade for vulnerable populations; 4th-5th grade for health literacy challenges).
2. **Extract legal elements**: Catalog all required regulatory elements: purpose, procedures, risks, benefits, alternatives, confidentiality, compensation, contacts, voluntary participation statement.
3. **Checkpoint**: Verify with user that all required legal elements are captured before simplification begins. If elements are missing, list them explicitly.
4. **Simplify each section**: Break sentences >20 words; replace jargon with common terms (use active voice, "you/your"); add visual aid placeholders.
5. **Clarify risks and benefits**: Present risk/benefit information in table format with likelihood and severity. Use emoji or color scales for accessibility.
6. **Checkpoint**: User confirms that risk/benefit balance is accurately preserved after simplification. If risk is downplayed, revise.
7. **Assess readability**: Run readability assessment. If target grade not met, iterate on complex sections.
8. **Check compliance**: Validate against FDA 21CFR50, ICH-GCP, HIPAA. Flag any missing elements.
9. **Output**: Deliver simplified document with readability metrics (grade level, suggestions) and compliance status.
10. **Fallback**: If source document is too fragmentary to simplify, return a structured checklist of missing elements and a partial simplification of available sections.

## Quick Start

```python
from scripts.consent_simplifier import ConsentSimplifier

simplifier = ConsentSimplifier()

# Simplify consent form
simplified = simplifier.simplify(
    document="clinical_trial_consent.pdf",
    reading_level="8th_grade",
    preserve_legal=True
)
```

## Core Capabilities

### 1. Document Simplification

```python
result = simplifier.simplify_section(
    section="procedure_description",
    text="Lumbar puncture will be performed under sterile conditions...",
    max_sentences=3
)
```

**Simplification Rules:**
- Break long sentences (>20 words)
- Replace medical jargon with common terms
- Use active voice
- Add visual aids placeholders
- Maintain key legal elements

### 2. Risk/Benefit Clarification

```python
risks = simplifier.clarify_risks(
    original_text="Potential adverse events include...",
    format="table",
    severity_scale="emoji"  # or "color", "text"
)
```

**Risk Presentation:**
| Risk | Likelihood | Severity |
|------|-----------|----------|
| Headache | Common (1 in 10) | Mild 😊 |
| Infection | Rare (1 in 1000) | Serious ⚠️ |

### 3. Reading Level Assessment

```python
metrics = simplifier.assess_readability(document)
print(f"Flesch Reading Ease: {metrics.flesch_reading_ease}")
print(f"Flesch-Kincaid Grade Level: {metrics.fk_grade_level}")
print(f"Suggested improvements: {metrics.suggestions}")
```

#### Flesch Reading Ease Score (v1.1.0)

**Formula:** `206.835 - 1.015 × (total words / total sentences) - 84.6 × (total syllables / total words)`

| Score Range | Readability Level | Description | Typical Audience |
|---|---|---|---|
| 90–100 | Very Easy | Very easy to read, conversational | 4th grade / age 9–10 |
| 80–89 | Easy | Easy to read | 5th grade |
| 70–79 | Fairly Easy | Fairly easy to read | 6th grade |
| **60–69** | **Standard** | **Plain English, easily understood** | **7th–8th grade (target for consent forms)** |
| 50–59 | Fairly Difficult | Fairly difficult to read | 9th–10th grade |
| 30–49 | Difficult | Difficult to read, academic | College level |
| 0–29 | Very Confusing | Very difficult, highly technical | Graduate / professional |

#### Flesch-Kincaid Grade Level (v1.1.0)

**Formula:** `0.39 × (total words / total sentences) + 11.8 × (total syllables / total words) - 15.59`

| Grade Level | Interpretation | Suitability |
|---|---|---|
| **≤ 5.0** | Very simple | Vulnerable populations, health literacy challenges |
| **5.1–6.0** | Simple | Elderly, low-literacy populations |
| **6.1–8.0** | Moderate | **General population (target range)** |
| **8.1–10.0** | Moderately complex | High school reading level |
| **10.1–12.0** | Complex | College-level reading |
| **> 12.0** | Very complex | Graduate / professional level — unsuitable for consent |

#### Combined Readability Report (output in v1.1.0)

When assessing a document, output a readability summary:

```text
--- READABILITY REPORT ---
Flesch Reading Ease:     62.3 (Standard - Plain English)
Flesch-Kincaid Grade:     7.5 (8th grade — within target range)

Additional Metrics:
  Average words per sentence:  14.2
  Average syllables per word:   1.6
  Percentage of passive voice:  12%
  Percentage of complex words:  8%

Target Grade Level:     6th-8th grade (general population)
Status:                 WITHIN TARGET RANGE ✓
```

**Target Levels:**
- **General population**: 8th grade (FRE 60–70)
- **Vulnerable populations**: 6th grade (FRE 70–80)
- **Health literacy challenges**: 4th-5th grade (FRE 80+)

#### Improvement Guidance

If readability is below target, provide specific suggestions:
- **Long sentences (>20 words):** Break into 2–3 shorter sentences
- **Complex words (≥3 syllables):** Replace with simpler alternatives
- **Passive voice:** Convert to active voice
- **Jargon terms:** Replace with plain language equivalents (see replacement dictionary)
- **Technical abbreviations:** Spell out on first use

### 4. Regulatory Compliance Check

```python
compliance = simplifier.check_compliance(
    simplified_document,
    regulations=["FDA_21CFR50", "ICH-GCP", "HIPAA"]
)
```

**Required Elements:**
- [ ] Purpose of research
- [ ] Procedures involved
- [ ] Risks and discomforts
- [ ] Benefits
- [ ] Alternatives
- [ ] Confidentiality
- [ ] Compensation
- [ ] Contact information
- [ ] Voluntary participation

## CLI Usage

```text
# Simplify PDF
python scripts/consent_simplifier.py \
  --input consent_form.pdf \
  --output simplified_consent.pdf \
  --grade-level 8

# Check compliance only
python scripts/consent_simplifier.py \
  --check compliance \
  --input document.pdf
```

## Best Practices

**Do:**
- Use "you" and "your"
- Define terms on first use
- Use bullet points for lists
- Include visual aids
- Test with patient advocates

**Don't:**
- Remove required legal elements
- Downplay significant risks
- Use coercive language
- Exceed recommended length

---

**Skill ID**: 208 | **Version**: 1.0 | **License**: MIT

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `patient-consent-simplifier` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `patient-consent-simplifier` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.
