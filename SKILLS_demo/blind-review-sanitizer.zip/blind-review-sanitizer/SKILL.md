---
name: blind-review-sanitizer
description: Use blind-review-sanitizer for academic writing workflows that need structured anonymization, explicit assumptions, and clear output boundaries for double-blind submission.
license: MIT
skill-author: AIPOCH
---
# Blind Review Sanitizer

Structured manuscript anonymization for double-blind peer review.

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
```

## When to Use

- Use this skill when the task needs removal or review of author-identifying content in manuscripts prepared for double-blind submission.
- Use this skill for academic writing tasks that require explicit assumptions, bounded scope, and a reproducible output format.
- Use this skill when you need a documented fallback path for missing inputs, execution errors, or partial evidence.

## Workflow

1. Confirm the submission target, source file type, anonymization strictness, and whether acknowledgments should be preserved.
2. Check whether the provided material is a supported file format and whether author names or known identifiers are available.
3. Use the packaged script for supported files; otherwise produce a manual anonymization checklist without claiming full sanitization.
4. Return the sanitized artifact or a verification plan that separates changes made, remaining risks, and manual review points.
5. If the request lacks a file path or enough identifiers, stop and request the minimum missing input.

## Use Cases

- Blind a manuscript before conference submission
- Review acknowledgments and self-citations for deanonymization risk
- Produce a manual anonymity checklist when automated processing is not possible

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `--input`, `-i` | string | Yes | - | Input manuscript file path (`.docx`, `.md`, `.txt`) |
| `--output`, `-o` | string | No | auto-generated | Output path with blinded suffix when omitted |
| `--authors` | string | No | - | Comma-separated author names for stronger detection |
| `--keep-acknowledgments` | flag | No | false | Preserve acknowledgment section |
| `--highlight-self-cites` | flag | No | false | Highlight self-citations without replacement |

## Returns

- Sanitized manuscript file for supported formats
- Summary of removed identifiers when available
- Explicit note when manual verification is still required

## Example

`python scripts/main.py --input manuscript.md --authors "Alice Chen,Bob Smith"`

## Risk Assessment

| Risk Indicator | Assessment | Level |
|----------------|------------|-------|
| Code Execution | Local Python script execution only | Medium |
| Network Access | No external API calls | Low |
| File System Access | Reads manuscript files and writes blinded output | Medium |
| Instruction Tampering | Standard prompt-guided workflow | Low |
| Data Exposure | Sensitive manuscript content remains local to workspace | Medium |

## Security Checklist

- [ ] No hardcoded credentials or API keys
- [ ] No unauthorized file system access (`../`)
- [ ] Sensitive manuscript content stays within approved workspace
- [ ] Input file paths validated before processing
- [ ] Output file path reviewed before overwrite
- [ ] Error messages do not fabricate successful sanitization
- [ ] Manual review required before submission
- [ ] Metadata cleanup handled separately when needed

## Prerequisites

Optional dependency: `python-docx` is required only for `.docx` processing.

## Evaluation Criteria

### Success Metrics
- [ ] Script path parses successfully
- [ ] Help output documents supported options
- [ ] Sanitization stays within double-blind preparation scope
- [ ] Missing file or missing identifiers trigger bounded fallback

### Test Cases
1. **Basic Functionality**: Help output and script parse succeed
2. **Edge Case**: Missing file path triggers explicit stop condition
3. **Output Quality**: Remaining anonymity risks are called out clearly

## Lifecycle Status

- **Current Stage**: Draft
- **Next Review Date**: 2026-03-20
- **Known Issues**: File metadata and embedded image review still require manual checks
- **Planned Improvements**:
  - Safer sample-file smoke test for richer audit coverage
  - More explicit metadata cleanup guidance

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `blind-review-sanitizer` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `blind-review-sanitizer` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.

## References

- [references/audit-reference.md](references/audit-reference.md) - Supported scope, audit commands, and fallback boundaries

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.

## When Not to Use

- 缺少完成任务所必需的输入文件、标识符、参数或上下文时，不要继续，先要求用户补充。
- 用户要求超出本 skill 已声明范围的推断、外部操作或权限时，不要自行假设具备这些能力。
- 需要覆盖已有结果、执行高成本批量操作或扩大任务范围时，不要直接继续，先和用户确认。

## Required Inputs

| 字段 | 必填 | 格式/来源 | 示例 | 缺失时处理 |
|---|---|---|---|---|
| 用户任务说明 | 是 | 文本 | 研究问题、写作目标、分析目标 | 缺失时停止并要求补充 |
| 主要输入材料 | 视任务而定 | 文本、文件路径、ID、表格或文献 | PMID、PDF、CSV、DOCX、主题词等 | 明确指出缺少哪类材料 |
| 输出偏好 | 否 | 文本 | 语言、格式、目标期刊、模板 | 未提供时采用 skill 默认格式 |

## Output Contract

- 主输出：与本 skill 目标一致的结构化结果或目标文件。
- 可选输出：中间检查说明、问题清单、补充建议或生成文件路径。
- 格式要求：除非用户另有要求，优先返回稳定、可复核的 Markdown 或 JSON；若 skill 自带脚本要求固定格式，则按该格式输出。
- 若为部分完成：必须显式标注 PARTIAL，并说明哪些步骤已完成、哪些步骤未完成。

## Failure Handling

- 缺少关键输入时：明确指出缺少的字段、文件或标识符，并暂停继续。
- 脚本、模板或资源执行失败时：报告失败步骤、可能原因和恢复建议，不要静默降级。
- 只能部分完成时：先返回已验证部分，再列出剩余阻塞项和建议的下一步。

## User Checkpoints

- 在执行批量处理、覆盖文件、长耗时检索或多阶段生成前，先向用户确认范围和输出格式。
- 在关键判断存在歧义、证据不足或需要进入下一阶段前，先向用户确认是否继续。

## Quick Validation

- 检查本 skill 依赖的关键脚本、模板或参考资料路径是否存在。
- 检查最终输出是否包含本任务约定的核心字段、章节或文件。
- 检查结果中是否清楚标注假设、限制和未完成项。
