---
name: pathology-roi-selector
description: Select and extract Regions of Interest (ROIs) from Whole Slide Images (WSI) for AI model training, tissue microarray creation, and pathology research. Detects tissue regions, computes quality metrics, and exports crop coordinates at specified magnifications.
keywords:
  - pathology-roi
  - wsi
  - whole-slide-image
  - tissue-detection
  - ai-training-data
  - digital-pathology
license: MIT
skill-author: AIPOCH
---
# Pathology ROI Selector

WSI region detection for AI training.

## Quick Check

Use this command to verify that the packaged script entry point can be parsed before deeper execution.

```bash
python -m py_compile scripts/main.py
```

## Audit-Ready Commands

Use these concrete commands for validation. They are intentionally self-contained and avoid placeholder paths.

```bash
python -m py_compile scripts/main.py
python scripts/main.py --help
```

## When to Use

- Selecting tumor-rich regions from WSI for AI training data
- Creating tissue microarray cores from digital slides
- Extracting ROI coordinates for pathology education materials
- Preparing quality-controlled image crops from 100K×100K WSI files

## Workflow

1. **Load WSI** — Input: wsi_file path → verify format (.svs/.ndpi/.tiff), check file integrity → Output: WSI metadata (dimensions, magnification levels, vendor)
2. **Detect tissue regions** — Input: tissue_type (tumor/normal) → apply tissue detection algorithm at low magnification → Output: tissue mask with region boundaries
3. **Compute quality metrics** — For each detected region: tissue percentage, blur score, color consistency → Output: quality score per region
4. **Select ROIs** — Input: magnification (20x/40x), minimum region size → rank regions by quality and tissue type match → ⛔ Checkpoint: Present top ROI candidates to user for confirmation before export → Output: selected ROI coordinates
5. **Export crops** — Generate export-ready image patches at specified magnification with coordinate metadata → Output: crop images + coordinates JSON

## Use Cases
- Tissue microarray creation
- AI model training data
- Pathology education
- Research sampling

## Parameters
- `wsi_file`: Whole slide image
- `tissue_type`: Tumor/normal
- `magnification`: 20x/40x

## Returns
- ROI coordinates
- Tissue percentage
- Quality metrics
- Export ready crops

## Example
Identify tumor-rich regions from 100K x 100K image

## Risk Assessment

| Risk Indicator | Assessment | Level |
|----------------|------------|-------|
| Code Execution | Python/R scripts executed locally | Medium |
| Network Access | No external API calls | Low |
| File System Access | Read input files, write output files | Medium |
| Instruction Tampering | Standard prompt guidelines | Low |
| Data Exposure | Output files saved to workspace | Low |

## Security Checklist

- [ ] No hardcoded credentials or API keys
- [ ] No unauthorized file system access (../)
- [ ] Output does not expose sensitive information
- [ ] Prompt injection protections in place
- [ ] Input file paths validated (no ../ traversal)
- [ ] Output directory restricted to workspace
- [ ] Script execution in sandboxed environment
- [ ] Error messages sanitized (no stack traces exposed)
- [ ] Dependencies audited

## Prerequisites

No additional Python packages required.

## Evaluation Criteria

### Success Metrics
- [ ] Successfully executes main functionality
- [ ] Output meets quality standards
- [ ] Handles edge cases gracefully
- [ ] Performance is acceptable

### Test Cases
1. **Basic Functionality**: Standard input → Expected output
2. **Edge Case**: Invalid input → Graceful error handling
3. **Performance**: Large dataset → Acceptable processing time

## Lifecycle Status

- **Current Stage**: Draft
- **Next Review Date**: 2026-03-06
- **Known Issues**: None
- **Planned Improvements**: 
  - Performance optimization
  - Additional feature support

## Output Requirements

Every final response should make these items explicit when they are relevant:

- Objective or requested deliverable
- Inputs used and assumptions introduced
- Workflow or decision path
- Core result, recommendation, or artifact
- Constraints, risks, caveats, or validation needs
- Unresolved items and next-step checks

## Error Handling

- If required inputs are missing, state exactly which fields are missing and request only the minimum additional information.
- If the task goes outside the documented scope, stop instead of guessing or silently widening the assignment.
- If `scripts/main.py` fails, report the failure point, summarize what still can be completed safely, and provide a manual fallback.
- Do not fabricate files, citations, data, search results, or execution outcomes.

## Input Validation

This skill accepts requests that match the documented purpose of `pathology-roi-selector` and include enough context to complete the workflow safely.

Do not continue the workflow when the request is out of scope, missing a critical input, or would require unsupported assumptions. Instead respond:

> `pathology-roi-selector` only handles its documented workflow. Please provide the missing required inputs or switch to a more suitable skill.

## Response Template

Use the following fixed structure for non-trivial requests:

1. Objective
2. Inputs Received
3. Assumptions
4. Workflow
5. Deliverable
6. Risks and Limits
7. Next Checks

If the request is simple, you may compress the structure, but still keep assumptions and limits explicit when they affect correctness.
