#!/usr/bin/env python3
"""
使用 PMC 官方 BioC API 下载单篇 PMC 全文。

默认只依赖 Python 标准库。把需要下载的 PMID/PMCID 填到
IDENTIFIERS 里，然后执行：

    python scripts/download_pmc_bioc.py

输出会写到 OUTPUT_DIR/<identifier>/ 下，并生成一个 manifest.json。
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path


# =========================
# 配置区
# =========================
IDENTIFIERS = [
    # "PMC1234567",
    # "12345678",
]
FORMAT = "xml"  # 可选：xml / json
ENCODING = "unicode"  # 可选：unicode / ascii
OUTPUT_DIR = Path("pmc-downloads")
TIMEOUT_SECONDS = 60
OVERWRITE = False


def build_url(identifier: str, format_name: str = FORMAT, encoding: str = ENCODING) -> str:
    return (
        "https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/"
        f"BioC_{format_name}/{identifier}/{encoding}"
    )


def download_one(
    identifier: str,
    output_dir: Path = OUTPUT_DIR,
    format_name: str = FORMAT,
    encoding: str = ENCODING,
    overwrite: bool = OVERWRITE,
) -> Path:
    url = build_url(identifier, format_name=format_name, encoding=encoding)
    target_dir = output_dir / identifier
    target_dir.mkdir(parents=True, exist_ok=True)

    suffix = ".xml" if format_name.lower() == "xml" else ".json"
    data_path = target_dir / f"BioC_{format_name}_{encoding}{suffix}"
    manifest_path = target_dir / "manifest.json"

    if data_path.exists() and not overwrite:
        raise FileExistsError(f"已存在文件，且 OVERWRITE=False: {data_path}")

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (compatible; PMC-Official-Download-Skill/1.0)"
        },
    )

    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            payload = response.read()
            status = getattr(response, "status", 200)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(
            f"下载失败：{identifier} 不一定在 PMC 可公开获取集合中，或官方服务暂时不可用。"
        ) from exc

    if not payload:
        raise RuntimeError(
            f"下载失败：{identifier} 没有返回内容，可能不在 PMC Open Access Subset 或 Author Manuscript Collection 中。"
        )

    data_path.write_bytes(payload)

    manifest = {
        "identifier": identifier,
        "source_service": "PMC BioC API",
        "source_url": url,
        "format": format_name,
        "encoding": encoding,
        "downloaded_at_utc": _dt.datetime.now(tz=_dt.timezone.utc).isoformat(),
        "http_status": status,
        "output_file": str(data_path),
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return data_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="使用 PMC 官方 BioC API 下载单篇或多篇公开可获取文献。"
    )
    parser.add_argument(
        "--identifier",
        action="append",
        dest="identifiers",
        help="PMID 或 PMCID，可重复传入多次，例如 --identifier PMC11787101 --identifier 41875094",
    )
    parser.add_argument(
        "--format",
        choices=("xml", "json"),
        default=FORMAT,
        help="输出格式，默认 xml",
    )
    parser.add_argument(
        "--encoding",
        choices=("unicode", "ascii"),
        default=ENCODING,
        help="字符编码模式，默认 unicode",
    )
    parser.add_argument(
        "--output-dir",
        default=str(OUTPUT_DIR),
        help=f"输出目录，默认：{OUTPUT_DIR}",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="若文件已存在则覆盖",
    )
    parser.add_argument(
        "--use-default-list",
        action="store_true",
        help="忽略命令行参数，改用脚本顶部的 IDENTIFIERS 列表",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    identifiers = IDENTIFIERS if args.use_default_list or not args.identifiers else args.identifiers

    if not identifiers:
        print("请先传入 --identifier，或者在脚本顶部的 IDENTIFIERS 中填入 PMID 或 PMCID。", file=sys.stderr)
        return 1

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    failures = 0

    for identifier in identifiers:
        try:
            saved = download_one(
                identifier,
                output_dir=output_dir,
                format_name=args.format,
                encoding=args.encoding,
                overwrite=args.overwrite or OVERWRITE,
            )
            print(f"已下载：{identifier} -> {saved}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"失败：{identifier} -> {exc}", file=sys.stderr)

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
