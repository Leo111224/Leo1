#!/usr/bin/env python3
"""
PMC 官方下载统一入口。

这个脚本是首选入口：

- 传 `--pmcid` 时，下载 PMC 官方 PDF
- 传 `--identifier` 时，下载 PMC BioC

尽量让调用者只记这一份脚本，而不是分别记 PDF 和 BioC 两个入口。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from download_pmc_bioc import download_one as download_bioc_one
from download_selected_pmc_pdfs import download_pdf, fetch_article_metadata


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PMC 官方下载统一入口")
    parser.add_argument(
        "--pmcid",
        action="append",
        help="下载官方 PDF 的 PMCID，可重复传入多次",
    )
    parser.add_argument(
        "--identifier",
        action="append",
        help="下载 BioC 的 PMID 或 PMCID，可重复传入多次",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="输出目录。默认按模式自动选择：PDF 用 pmc-downloads/pdf，BioC 用 pmc-downloads/bioc",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="若文件已存在则覆盖",
    )
    parser.add_argument(
        "--bioc-format",
        choices=("xml", "json"),
        default="xml",
        help="BioC 输出格式，默认 xml",
    )
    parser.add_argument(
        "--bioc-encoding",
        choices=("unicode", "ascii"),
        default="unicode",
        help="BioC 输出字符编码，默认 unicode",
    )
    parser.add_argument(
        "--use-default-pdf-list",
        action="store_true",
        help="忽略 --pmcid，改用脚本内置的 PDF 示例列表",
    )
    parser.add_argument(
        "--use-default-bioc-list",
        action="store_true",
        help="忽略 --identifier，改用脚本内置的 BioC 示例列表",
    )
    return parser.parse_args()


def run_pdf(pmcids: list[str], output_dir: Path, overwrite: bool) -> int:
    failures = 0
    for pmcid in pmcids:
        try:
            article = fetch_article_metadata(pmcid)
            manifest = download_pdf(article, output_dir=output_dir, overwrite=overwrite)
            print(f"已下载：{pmcid} -> {manifest['output_file']}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"失败：{pmcid} -> {exc}", file=sys.stderr)
    return failures


def run_bioc(
    identifiers: list[str],
    output_dir: Path,
    overwrite: bool,
    bioc_format: str,
    bioc_encoding: str,
) -> int:
    failures = 0
    for identifier in identifiers:
        try:
            saved = download_bioc_one(
                identifier,
                output_dir=output_dir,
                format_name=bioc_format,
                encoding=bioc_encoding,
                overwrite=overwrite,
            )
            print(f"已下载：{identifier} -> {saved}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"失败：{identifier} -> {exc}", file=sys.stderr)
    return failures


def main() -> int:
    args = parse_args()

    pdf_mode = bool(args.pmcid) or args.use_default_pdf_list
    bioc_mode = bool(args.identifier) or args.use_default_bioc_list

    if pdf_mode and bioc_mode:
        print("请只选择一种模式：要么传 --pmcid，要么传 --identifier。", file=sys.stderr)
        return 1

    if not pdf_mode and not bioc_mode:
        print("请至少传入 --pmcid 或 --identifier。", file=sys.stderr)
        return 1

    overwrite = args.overwrite
    if pdf_mode:
        pmcids = args.pmcid or []
        if not pmcids:
            from download_selected_pmc_pdfs import ARTICLES as DEFAULT_PDF_ARTICLES

            pmcids = [article["pmcid"] for article in DEFAULT_PDF_ARTICLES]
        output_dir = Path(args.output_dir or "pmc-downloads/pdf")
        output_dir.mkdir(parents=True, exist_ok=True)
        failures = run_pdf(pmcids, output_dir=output_dir, overwrite=overwrite)
        if failures:
            print(f"完成，但有 {failures} 篇失败。", file=sys.stderr)
            return 1
        print(f"全部完成，输出目录：{output_dir}")
        return 0

    identifiers = args.identifier or []
    if not identifiers:
        from download_pmc_bioc import IDENTIFIERS as DEFAULT_IDENTIFIERS

        identifiers = [item for item in DEFAULT_IDENTIFIERS if item]

    output_dir = Path(args.output_dir or "pmc-downloads/bioc")
    output_dir.mkdir(parents=True, exist_ok=True)
    failures = run_bioc(
        identifiers,
        output_dir=output_dir,
        overwrite=overwrite,
        bioc_format=args.bioc_format,
        bioc_encoding=args.bioc_encoding,
    )
    if failures:
        print(f"完成，但有 {failures} 篇失败。", file=sys.stderr)
        return 1
    print(f"全部完成，输出目录：{output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
